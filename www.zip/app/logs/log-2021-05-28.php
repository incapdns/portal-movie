<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/app/models/Site.php 1229
ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/app/models/Site.php 1229
ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/app/models/Site.php 1229
ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/app/models/Site.php 1229
ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/app/models/Site.php 1229
ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/app/models/Site.php 1229
ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/app/models/Site.php 1229
ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/app/models/Site.php 1229
ERROR - 2021-05-28 14:52:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/saleem/Sites/sma/system/core/Exceptions.php:271) /Users/saleem/Sites/sma/system/helpers/url_helper.php 564
