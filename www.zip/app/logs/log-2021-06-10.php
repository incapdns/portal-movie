<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-10 11:24:01 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 90
ERROR - 2021-06-10 11:24:01 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 247
ERROR - 2021-06-10 11:25:07 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-06-10 11:25:14 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 90
ERROR - 2021-06-10 11:25:14 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 247
ERROR - 2021-06-10 11:25:24 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 90
ERROR - 2021-06-10 11:25:24 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 247
ERROR - 2021-06-10 11:26:24 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/customers/index.php 45
ERROR - 2021-06-10 11:26:24 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/customers/index.php 139
ERROR - 2021-06-10 11:26:24 --> Query error: Unknown column 'due_limit' in 'field list' - Invalid query: SELECT `id`, `company`, `name`, `email`, `phone`, `price_group_name`, `customer_group_name`, `vat_no`, `gst_no`, `payment_term`, `due_limit`, `deposit_amount`, `award_points`
FROM `sma_companies`
WHERE `group_name` = 'customer'
ORDER BY `company` ASC
 LIMIT 10
ERROR - 2021-06-10 11:29:05 --> Severity: Warning --> Undefined array key "bulk_actions" /Users/saleem/Sites/sma/themes/default/admin/views/customers/index.php 45
ERROR - 2021-06-10 11:29:05 --> Severity: Warning --> Undefined array key "bulk_actions" /Users/saleem/Sites/sma/themes/default/admin/views/customers/index.php 139
ERROR - 2021-06-10 11:29:05 --> Query error: Unknown column 'due_limit' in 'field list' - Invalid query: SELECT `id`, `company`, `name`, `email`, `phone`, `price_group_name`, `customer_group_name`, `vat_no`, `gst_no`, `payment_term`, `due_limit`, `deposit_amount`, `award_points`
FROM `sma_companies`
WHERE `group_name` = 'customer'
ORDER BY `company` ASC
 LIMIT 10
ERROR - 2021-06-10 11:29:49 --> Severity: Warning --> Undefined array key "bulk_actions" /Users/saleem/Sites/sma/themes/default/admin/views/customers/index.php 45
ERROR - 2021-06-10 11:29:49 --> Severity: Warning --> Undefined array key "bulk_actions" /Users/saleem/Sites/sma/themes/default/admin/views/customers/index.php 139
ERROR - 2021-06-10 11:29:49 --> Query error: Unknown column 'due_limit' in 'field list' - Invalid query: SELECT `id`, `company`, `name`, `email`, `phone`, `price_group_name`, `customer_group_name`, `vat_no`, `gst_no`, `payment_term`, `due_limit`, `deposit_amount`, `award_points`
FROM `sma_companies`
WHERE `group_name` = 'customer'
ORDER BY `company` ASC
 LIMIT 10
ERROR - 2021-06-10 11:29:58 --> Query error: Unknown column 'due_limit' in 'field list' - Invalid query: SELECT `id`, `company`, `name`, `email`, `phone`, `price_group_name`, `customer_group_name`, `vat_no`, `gst_no`, `payment_term`, `due_limit`, `deposit_amount`, `award_points`
FROM `sma_companies`
WHERE `group_name` = 'customer'
ORDER BY `company` ASC
 LIMIT 10
ERROR - 2021-06-10 11:54:46 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-06-10 13:47:18 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 90
ERROR - 2021-06-10 13:47:18 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 247
ERROR - 2021-06-10 13:47:31 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-06-10 13:51:04 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 90
ERROR - 2021-06-10 13:51:04 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 247
ERROR - 2021-06-10 13:51:08 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-06-10 13:57:25 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 90
ERROR - 2021-06-10 13:57:25 --> Severity: Warning --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 247
ERROR - 2021-06-10 13:57:28 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-06-10 13:59:51 --> Severity: Notice --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 90
ERROR - 2021-06-10 13:59:51 --> Severity: Notice --> Trying to access array offset on value of type null /Users/saleem/Sites/sma/themes/default/admin/views/products/index.php 247
