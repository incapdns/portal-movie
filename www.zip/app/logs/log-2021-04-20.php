<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-20 06:02:44 --> Severity: Notice --> Undefined index: HTTP_REFERER /Users/saleem/Sites/sma/app/controllers/Notify.php 25
ERROR - 2021-04-20 06:51:52 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT) /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 731
ERROR - 2021-04-20 06:52:15 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT) /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 731
ERROR - 2021-04-20 06:52:20 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT) /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 731
ERROR - 2021-04-20 06:52:20 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT) /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 731
ERROR - 2021-04-20 07:02:07 --> Severity: Warning --> Undefined variable $ch /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 717
ERROR - 2021-04-20 07:02:07 --> Severity: error --> Exception: curl_setopt(): Argument #1 ($handle) must be of type CurlHandle, null given /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 717
ERROR - 2021-04-20 07:02:09 --> Severity: Warning --> Undefined variable $ch /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 717
ERROR - 2021-04-20 07:02:09 --> Severity: error --> Exception: curl_setopt(): Argument #1 ($handle) must be of type CurlHandle, null given /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 717
ERROR - 2021-04-20 07:04:18 --> Severity: Warning --> Array to string conversion /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 750
ERROR - 2021-04-20 07:04:23 --> Severity: Warning --> Array to string conversion /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 750
ERROR - 2021-04-20 07:06:40 --> Severity: error --> Exception: Call to undefined function random_string() /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 735
ERROR - 2021-04-20 07:06:44 --> Severity: error --> Exception: Call to undefined function random_string() /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 735
ERROR - 2021-04-20 07:08:40 --> Severity: Warning --> Undefined array key "RESPONSE" /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 729
ERROR - 2021-04-20 07:10:10 --> Severity: Warning --> Undefined array key "RESPONSE" /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 729
ERROR - 2021-04-20 07:12:20 --> Severity: Warning --> Undefined array key "RESPONSE" /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 729
ERROR - 2021-04-20 07:13:47 --> Severity: Warning --> Undefined array key "RESPONSE" /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 729
ERROR - 2021-04-20 07:19:44 --> Severity: Warning --> Attempt to read property "id" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 555
ERROR - 2021-04-20 07:19:44 --> Severity: Warning --> Attempt to read property "company" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 555
ERROR - 2021-04-20 07:19:44 --> Severity: Warning --> Attempt to read property "name" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 555
ERROR - 2021-04-20 23:14:25 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting "]" /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 743
ERROR - 2021-04-20 23:14:33 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting "]" /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 743
ERROR - 2021-04-20 23:14:37 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting "]" /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 743
ERROR - 2021-04-20 23:18:23 --> Severity: Warning --> Attempt to read property "id" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 555
ERROR - 2021-04-20 23:18:23 --> Severity: Warning --> Attempt to read property "company" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 555
ERROR - 2021-04-20 23:18:23 --> Severity: Warning --> Attempt to read property "name" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 555
