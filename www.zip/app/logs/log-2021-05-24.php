<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-24 09:48:24 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-05-24 09:48:29 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/themes/default/admin/views/pos/view.php 156
ERROR - 2021-05-24 09:48:29 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-05-24 09:48:58 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-05-24 11:57:17 --> Query error: Table 'test2.sma_cart' doesn't exist - Invalid query: SELECT *
FROM `sma_cart`
WHERE `id` = '2506b6077073cbe4d2c11996a59001df'
ERROR - 2021-05-24 11:57:33 --> Query error: Table 'test2.sma_cart' doesn't exist - Invalid query: SELECT *
FROM `sma_cart`
WHERE `id` = '2506b6077073cbe4d2c11996a59001df'
ERROR - 2021-05-24 11:58:04 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/themes/default/admin/views/settings/index.php 522
ERROR - 2021-05-24 11:58:04 --> Severity: error --> Exception: Undefined constant "self" /Users/saleem/Sites/sma/themes/default/admin/views/settings/index.php 1020
ERROR - 2021-05-24 11:58:07 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/themes/default/admin/views/settings/index.php 522
ERROR - 2021-05-24 11:58:07 --> Severity: error --> Exception: Undefined constant "self" /Users/saleem/Sites/sma/themes/default/admin/views/settings/index.php 1020
ERROR - 2021-05-24 11:58:12 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/themes/default/admin/views/settings/index.php 522
ERROR - 2021-05-24 11:58:12 --> Severity: error --> Exception: Undefined constant "self" /Users/saleem/Sites/sma/themes/default/admin/views/settings/index.php 1020
ERROR - 2021-05-24 12:01:25 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/themes/default/admin/views/settings/index.php 522
ERROR - 2021-05-24 12:02:01 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/themes/default/admin/views/settings/index.php 522
