<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-03 19:00:46 --> Severity: error --> Exception: Unclosed '{' on line 1446 /Users/saleem/Sites/sma/themes/default/admin/views/pos/add.php 2230
ERROR - 2021-05-03 19:24:29 --> Could not find the language line " note"
ERROR - 2021-05-03 19:25:00 --> Why else: Array
(
    [product_id] => 33
    [option_id] => 
    [warehouse_id] => 1
    [status] => received
    [product_unit_id] => 4
    [product_unit_code] => pc
    [product_code] => TA01
    [product_name] => Test Adjustment
    [item_tax] => 0.00
    [transfer_id] => 
    [purchase_id] => 
    [unit_cost] => 20
    [real_unit_cost] => 20.0000
    [net_unit_cost] => 20.0000
    [quantity_received] => 10
    [unit_quantity] => 10
    [quantity] => 10
    [quantity_balance] => 10
    [subtotal] => 200
    [tax] => 0
    [tax_rate_id] => 1
    [date] => 2021-05-03
)

ERROR - 2021-05-03 19:25:00 --> Could not find the language line " note"
ERROR - 2021-05-03 19:28:20 --> More than zero: 10 = 9.0000 + 1.0000 PI: stdClass Object
(
    [id] => 64
    [purchase_id] => 
    [transfer_id] => 
    [product_id] => 33
    [product_code] => TA01
    [product_name] => Test Adjustment
    [option_id] => 
    [net_unit_cost] => 20.0000
    [quantity] => 10.0000
    [warehouse_id] => 1
    [item_tax] => 0.0000
    [tax_rate_id] => 1
    [tax] => 0
    [discount] => 
    [item_discount] => 
    [expiry] => 
    [subtotal] => 200.0000
    [quantity_balance] => 9.0000
    [date] => 2021-05-03
    [status] => received
    [unit_cost] => 20.0000
    [real_unit_cost] => 20.0000
    [quantity_received] => 10.0000
    [supplier_part_no] => 
    [purchase_item_id] => 
    [product_unit_id] => 4
    [product_unit_code] => pc
    [unit_quantity] => 10.0000
    [gst] => 
    [cgst] => 
    [sgst] => 
    [igst] => 
    [base_unit_cost] => 
)

ERROR - 2021-05-03 19:28:31 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-05-03 19:34:01 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
