<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-17 09:36:32 --> Severity: Warning --> Undefined array key "HTTP_REFERER" /Users/saleem/Sites/sma/app/controllers/Notify.php 25
ERROR - 2021-06-17 09:38:47 --> Severity: Warning --> Attempt to read property "id" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 561
ERROR - 2021-06-17 09:38:47 --> Severity: Warning --> Attempt to read property "company" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 561
ERROR - 2021-06-17 09:38:47 --> Severity: Warning --> Attempt to read property "name" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 561
ERROR - 2021-06-17 09:38:47 --> Severity: Warning --> Attempt to read property "payment_term" on bool /Users/saleem/Sites/sma/app/controllers/admin/Customers.php 561
ERROR - 2021-06-17 09:39:40 --> More than zero: 10 = 9.0000 + 1.0000 PI: stdClass Object
(
    [id] => 48
    [purchase_id] => 6
    [transfer_id] => 
    [product_id] => 20
    [product_code] => TOY05
    [product_name] => Minion Reading
    [option_id] => 
    [net_unit_cost] => 9.4300
    [quantity] => 10.0000
    [warehouse_id] => 2
    [item_tax] => 5.7000
    [tax_rate_id] => 3
    [tax] => 6%
    [discount] => 0
    [item_discount] => 0.0000
    [expiry] => 
    [subtotal] => 100.0000
    [quantity_balance] => 9.0000
    [date] => 2021-06-17
    [status] => received
    [unit_cost] => 10.0000
    [real_unit_cost] => 10.0000
    [quantity_received] => 10.0000
    [supplier_part_no] => 
    [purchase_item_id] => 
    [product_unit_id] => 4
    [product_unit_code] => pc
    [unit_quantity] => 10.0000
    [gst] => 
    [cgst] => 
    [sgst] => 
    [igst] => 
    [base_unit_cost] => 
)

ERROR - 2021-06-17 09:47:00 --> More than zero: 10 = 9.0000 + 1.0000 PI: stdClass Object
(
    [id] => 37
    [purchase_id] => 5
    [transfer_id] => 
    [product_id] => 16
    [product_code] => TOY01
    [product_name] => Minion Bananas
    [option_id] => 
    [net_unit_cost] => 9.4300
    [quantity] => 10.0000
    [warehouse_id] => 1
    [item_tax] => 5.7000
    [tax_rate_id] => 3
    [tax] => 6%
    [discount] => 0
    [item_discount] => 0.0000
    [expiry] => 
    [subtotal] => 100.0000
    [quantity_balance] => 9.0000
    [date] => 2021-06-17
    [status] => received
    [unit_cost] => 10.0000
    [real_unit_cost] => 10.0000
    [quantity_received] => 10.0000
    [supplier_part_no] => 
    [purchase_item_id] => 
    [product_unit_id] => 4
    [product_unit_code] => pc
    [unit_quantity] => 10.0000
    [gst] => 
    [cgst] => 
    [sgst] => 
    [igst] => 
    [base_unit_cost] => 
)

ERROR - 2021-06-17 09:59:33 --> Severity: Warning --> Undefined array key "return_purchase_ref" /Users/saleem/Sites/sma/app/models/admin/Purchases_model.php 66
ERROR - 2021-06-17 10:05:00 --> More than zero: 40 = 30.0000 + 10.0000 PI: stdClass Object
(
    [id] => 57
    [purchase_id] => 
    [transfer_id] => 1
    [product_id] => 27
    [product_code] => GT01
    [product_name] => GTest
    [option_id] => 
    [net_unit_cost] => 10.0000
    [quantity] => 40.0000
    [warehouse_id] => 2
    [item_tax] => 0.0000
    [tax_rate_id] => 1
    [tax] => 0
    [discount] => 
    [item_discount] => 
    [expiry] => 
    [subtotal] => 400.0000
    [quantity_balance] => 30.0000
    [date] => 2021-06-17
    [status] => received
    [unit_cost] => 10.0000
    [real_unit_cost] => 10.0000
    [quantity_received] => 
    [supplier_part_no] => 
    [purchase_item_id] => 
    [product_unit_id] => 4
    [product_unit_code] => pc
    [unit_quantity] => 40.0000
    [gst] => 
    [cgst] => 
    [sgst] => 
    [igst] => 
    [base_unit_cost] => 
)

ERROR - 2021-06-17 10:52:35 --> More than zero: 30 = 25.0000 + 5.0000 PI: stdClass Object
(
    [id] => 57
    [purchase_id] => 
    [transfer_id] => 1
    [product_id] => 27
    [product_code] => GT01
    [product_name] => GTest
    [option_id] => 
    [net_unit_cost] => 10.0000
    [quantity] => 40.0000
    [warehouse_id] => 2
    [item_tax] => 0.0000
    [tax_rate_id] => 1
    [tax] => 0
    [discount] => 
    [item_discount] => 
    [expiry] => 
    [subtotal] => 400.0000
    [quantity_balance] => 25.0000
    [date] => 2021-06-17
    [status] => received
    [unit_cost] => 10.0000
    [real_unit_cost] => 10.0000
    [quantity_received] => 
    [supplier_part_no] => 
    [purchase_item_id] => 
    [product_unit_id] => 4
    [product_unit_code] => pc
    [unit_quantity] => 40.0000
    [gst] => 
    [cgst] => 
    [sgst] => 
    [igst] => 
    [base_unit_cost] => 
)

ERROR - 2021-06-17 10:53:45 --> More than zero: 30 = 20.0000 + 10.0000 PI: stdClass Object
(
    [id] => 57
    [purchase_id] => 
    [transfer_id] => 1
    [product_id] => 27
    [product_code] => GT01
    [product_name] => GTest
    [option_id] => 
    [net_unit_cost] => 10.0000
    [quantity] => 40.0000
    [warehouse_id] => 2
    [item_tax] => 0.0000
    [tax_rate_id] => 1
    [tax] => 0
    [discount] => 
    [item_discount] => 
    [expiry] => 
    [subtotal] => 400.0000
    [quantity_balance] => 20.0000
    [date] => 2021-06-17
    [status] => received
    [unit_cost] => 10.0000
    [real_unit_cost] => 10.0000
    [quantity_received] => 
    [supplier_part_no] => 
    [purchase_item_id] => 
    [product_unit_id] => 4
    [product_unit_code] => pc
    [unit_quantity] => 40.0000
    [gst] => 
    [cgst] => 
    [sgst] => 
    [igst] => 
    [base_unit_cost] => 
)

