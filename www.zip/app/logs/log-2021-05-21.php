<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-21 10:36:10 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/themes/default/admin/views/pos/view.php 156
ERROR - 2021-05-21 10:36:10 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-05-21 10:38:53 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /Users/saleem/Sites/sma/themes/default/admin/views/pos/view.php 156
ERROR - 2021-05-21 10:38:53 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
ERROR - 2021-05-21 10:46:33 --> Severity: error --> Exception: Unable to generate image: check your GD installation /Users/saleem/Sites/sma/vendor/endroid/qr-code/src/Writer/PngWriter.php 74
