<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-25 12:56:24 --> Query error: Unknown column 'title' in 'field list' - Invalid query: SELECT `title`, `slug`, `category_slug`
FROM `sma_products`
WHERE `name` LIKE '%tesw%' ESCAPE '!'
 LIMIT 10
ERROR - 2021-05-25 12:56:24 --> Query error: Unknown column 'title' in 'field list' - Invalid query: SELECT `title`, `slug`, `category_slug`
FROM `sma_products`
WHERE `name` LIKE '%tesw%' ESCAPE '!'
 LIMIT 10
ERROR - 2021-05-25 12:56:24 --> Query error: Unknown column 'title' in 'field list' - Invalid query: SELECT `title`, `slug`, `category_slug`
FROM `sma_products`
WHERE `name` LIKE '%tesw%' ESCAPE '!'
 LIMIT 10
ERROR - 2021-05-25 12:56:24 --> Query error: Unknown column 'title' in 'field list' - Invalid query: SELECT `title`, `slug`, `category_slug`
FROM `sma_products`
WHERE `name` LIKE '%tesw%' ESCAPE '!'
 LIMIT 10
ERROR - 2021-05-25 12:56:47 --> Query error: Unknown column 'category_slug' in 'field list' - Invalid query: SELECT `name`, `code`, `slug`, `category_slug`
FROM `sma_products`
WHERE `name` LIKE '%te%' ESCAPE '!'
 LIMIT 10
ERROR - 2021-05-25 12:56:47 --> Query error: Unknown column 'category_slug' in 'field list' - Invalid query: SELECT `name`, `code`, `slug`, `category_slug`
FROM `sma_products`
WHERE `name` LIKE '%te%' ESCAPE '!'
 LIMIT 10
ERROR - 2021-05-25 12:57:50 --> Severity: Warning --> Undefined property: Shop::$tec /Users/saleem/Sites/sma/app/controllers/shop/Shop.php 720
ERROR - 2021-05-25 12:57:50 --> Severity: error --> Exception: Call to a member function send_json() on null /Users/saleem/Sites/sma/app/controllers/shop/Shop.php 720
ERROR - 2021-05-25 12:57:50 --> Severity: Warning --> Undefined property: Shop::$tec /Users/saleem/Sites/sma/app/controllers/shop/Shop.php 720
ERROR - 2021-05-25 12:57:50 --> Severity: error --> Exception: Call to a member function send_json() on null /Users/saleem/Sites/sma/app/controllers/shop/Shop.php 720
ERROR - 2021-05-25 13:33:34 --> Severity: Warning --> Undefined array key "HTTP_REFERER" /Users/saleem/Sites/sma/app/controllers/shop/Shop.php 710
ERROR - 2021-05-25 13:50:54 --> Severity: Warning --> mkdir(): Invalid path /Users/saleem/Sites/sma/system/libraries/Session/drivers/Session_files_driver.php 136
ERROR - 2021-05-25 13:50:54 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2021-05-25 13:50:54 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) /Users/saleem/Sites/sma/system/libraries/Session/Session.php 143
ERROR - 2021-05-25 14:03:03 --> Severity: error --> Exception: syntax error, unexpected token "echo" /Users/saleem/Sites/sma/themes/default/shop/views/pages/page.php 21
