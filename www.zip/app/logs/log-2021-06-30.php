<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-30 00:56:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:56:30 --> Unable to connect to the database
ERROR - 2021-06-30 00:56:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:56:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ) C:\Program Files\VertrigoServ\www\system\libraries\Session\Session.php 143
ERROR - 2021-06-30 00:57:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:57:20 --> Unable to connect to the database
ERROR - 2021-06-30 00:57:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:57:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ) C:\Program Files\VertrigoServ\www\system\libraries\Session\Session.php 143
ERROR - 2021-06-30 00:57:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:57:21 --> Unable to connect to the database
ERROR - 2021-06-30 00:57:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:57:21 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ) C:\Program Files\VertrigoServ\www\system\libraries\Session\Session.php 143
ERROR - 2021-06-30 00:57:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:57:34 --> Unable to connect to the database
ERROR - 2021-06-30 00:57:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:57:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ) C:\Program Files\VertrigoServ\www\system\libraries\Session\Session.php 143
ERROR - 2021-06-30 00:57:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:57:44 --> Unable to connect to the database
ERROR - 2021-06-30 00:57:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\Program Files\VertrigoServ\www\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-30 00:57:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ) C:\Program Files\VertrigoServ\www\system\libraries\Session\Session.php 143
ERROR - 2021-06-30 00:58:17 --> Query error: Table 'asm.sma_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `sma_sessions`
WHERE `id` = 'e058a8f402223fc54b148318665f70aac627729b'
ERROR - 2021-06-30 00:58:17 --> Query error: Table 'asm.sma_sessions' doesn't exist - Invalid query: INSERT INTO `sma_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e058a8f402223fc54b148318665f70aac627729b', '127.0.0.1', 1625011097, '__ci_last_regenerate|i:1625011097;error|s:117:\"<h4>404 Not Found!</h4><p>The page you are looking for can not be found.</p>https://local.br/install/index.php?step=2\";__ci_vars|a:1:{s:5:\"error\";s:3:\"new\";}')
ERROR - 2021-06-30 00:58:17 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
ERROR - 2021-06-30 00:58:20 --> Query error: Table 'asm.sma_sessions' doesn't exist - Invalid query: SELECT 1
FROM `sma_sessions`
WHERE `id` = 'e058a8f402223fc54b148318665f70aac627729b'
ERROR - 2021-06-30 00:58:20 --> Query error: Table 'asm.sma_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `sma_sessions`
WHERE `id` = 'e058a8f402223fc54b148318665f70aac627729b'
ERROR - 2021-06-30 00:58:20 --> Query error: Table 'asm.sma_sessions' doesn't exist - Invalid query: INSERT INTO `sma_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e058a8f402223fc54b148318665f70aac627729b', '127.0.0.1', 1625011100, '__ci_last_regenerate|i:1625011100;error|s:117:\"<h4>404 Not Found!</h4><p>The page you are looking for can not be found.</p>https://local.br/install/index.php?step=3\";__ci_vars|a:1:{s:5:\"error\";s:3:\"new\";}')
ERROR - 2021-06-30 00:58:20 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ) Unknown 0
