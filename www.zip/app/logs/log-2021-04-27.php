<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-27 14:53:50 --> Severity: Notice --> Trying to get property 'discount' of non-object /Users/saleem/Sites/sma/app/controllers/admin/Pos.php 613
ERROR - 2021-04-27 14:53:50 --> Severity: Notice --> Trying to get property 'percent' of non-object /Users/saleem/Sites/sma/app/controllers/admin/Pos.php 616
ERROR - 2021-04-27 14:54:05 --> Severity: Notice --> Trying to get property 'discount' of non-object /Users/saleem/Sites/sma/app/controllers/admin/Pos.php 613
ERROR - 2021-04-27 14:54:05 --> Severity: Notice --> Trying to get property 'percent' of non-object /Users/saleem/Sites/sma/app/controllers/admin/Pos.php 616
ERROR - 2021-04-27 14:56:54 --> Severity: Notice --> Trying to get property 'discount' of non-object /Users/saleem/Sites/sma/app/controllers/admin/Pos.php 613
ERROR - 2021-04-27 14:56:54 --> Severity: Notice --> Trying to get property 'percent' of non-object /Users/saleem/Sites/sma/app/controllers/admin/Pos.php 616
ERROR - 2021-04-27 14:59:23 --> Severity: Notice --> Trying to get property 'percent' of non-object /Users/saleem/Sites/sma/app/controllers/admin/Pos.php 616
ERROR - 2021-04-27 15:10:19 --> Could not find the language line "remember_me"
