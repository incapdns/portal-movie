/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#include <stdio.h>
#include <locale.h>
#include "includes.h"
#include "clients.h"
#include "employees.h"
#include "rooms.h"
#include "stays.h"
#include "settings.h"

/**@brief
 * Procedimento responsavel por exibir todos os sub-menu da aplicação.\n\n
 * 0 - Sair do programa\n\n
 * C - Clientes - setting_menu()\n
 * 1 - Adicionar estadia - add_stay()\n
 * 2 - Funcionarios - employee_menu()\n
 * 3 - Quartos - room_menu()\n
 * 4 - Estadias - stay_menu()
*/
int main(void) {
  //LC_CTYPE: Somente funções de manipulação de caracteres
  //(Entrada [scanf] STDIN e outros não incluidos)
  setlocale(LC_CTYPE, "Portuguese");

  setenv("TZ", "America/Sao_Paulo", 1);
  tzset();
  
  set_diff_year();

  load_config();
  
  char option;
  
  do {
      printf("Sair: 0\n\n");
      printf("Configuracoes: C\n\n");
    
      printf("1: Clientes\n");
      printf("2: Funcionarios\n");
      printf("3: Quartos\n");
      printf("4: Estadias\n\n");

      printf("\nSua opcao: ");

      char buffer[10];
      afgets(buffer, 10);
      sscanf(buffer, "%c", &option);

      if(option == 48) continue;
    
      switch(option){
          case 'C':
            clrscr();
            setting_menu();
            break;

          case '1':
            clrscr();
            client_menu();
            break;

          case '2':
            clrscr();
            employee_menu();
            break;

          case '3':
            clrscr();
            room_menu();
            break;

          case '4':
            clrscr();
            stay_menu();
            break;

          default:
            printf("Opcao invalida\n");
      }

      pause();
      clrscr();
  } while (option != 48);

  release_clients();

  release_employees();

  release_rooms();

  release_stays();

  free(b_system_date);

  printf("\nFim da aplicacao!\n");

  pause();

  return 0;
}