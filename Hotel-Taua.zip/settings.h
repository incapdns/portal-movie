#ifndef SETTINGS_H  
#define SETTINGS_H
#include "includes.h"
#include "stays.h"
#include "clients.h"

extern time_t date;

extern int started;

extern char *b_system_date;

extern float discount;

//Proc de resetar todo o sistema
int reset_all();

//Proc de verificar estadias expiradas
int check_expired_stays(time_t, Stay *);

//Proc de setar data futura
int set_future_date();

//Proc de setar valor do desconto
int discount_config();

//Carregar configurações (valor do desconto e data atual)
void load_config();

//Mostrar menu
void setting_menu();

#endif