/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#ifndef ROOMS_H  
/*!
  \def ROOMS_H
  Declara que "ROOMS_H" está definido na aplicação, significando a já existência do mesmo
*/
#define ROOMS_H
#include "includes.h"

/**
 * \typedef typedef enum Status
 * @brief Seta o alias "Status" para o tipo de dado de enumeração enum Status
 */
/*!
  @brief
  Enumeração dos status existentes para um quarto
*/
typedef enum {
  NotAvailable,
  Available
} Status;

/**
 * \typedef typedef struct Room Room
 * @brief Seta o alias "Room" para a estrutura do tipo de dado "struct Room"
 */
/**
 * \struct Room
 * @brief Esta é a estrutura do quarto, que por sua vez é uma arvore binaria, e ela é responsavel por armazenar as informações do quarto, tal como o id, capacidade, preço da diaria, status, etc.
 */
typedef struct Room {
   /**
    * @name Campos da estrutura
   */
   /*@{*/
   int id; /**< O ID do quarto */
   int max; /**< O nome do quarto */
   float price; /**< O valor da diaria do quarto */
   Status status; /**< O status do quarto, sendo 0 = Não disponivel, 1 = Disponivel */
   /*@}*/

   /**
    * @name Continuação (arvore binaria)
   */
   struct Room *next;
   /*@}*/
} Room;

//Obter a string referente ao status
char *statusName(Status);

//Obter ID de quarto valido (se filtro ativado)
int ask_room_id(int, int);

//Retorna os quartos disponiveis
Result getAvailableRooms();

//Editar quarto
Room *editRoom(Room*, int);

//Mostras informações do quarto
Room *showRoom(Room*);

//Retornar quarto por ID
Room *getRoom(int);

//Proc de mostrar quartos disponiveis
int show_availables();

//Proc de adicionar quarto
int add_room();

//Proc de mostrar quarto
int show_room();

//Proc de editar quarto
int edit_room();

//Proc de deletar quarto
int del_room();

/*
   INICIO: Gravar, salvar, carregar, liberar dados do arquivo !
*/
int show_all_rooms();

int save_all_rooms();

void load_room(int);

extern int rooms_loaded;

int load_all_rooms();

void release_rooms();
/*
   FIM: Gravar, salvar, carregar, liberar dados do arquivo !
*/

//Mostrar menu
void room_menu();

#endif