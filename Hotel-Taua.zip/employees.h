/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#ifndef EMPLOYEES_H  
/*!
  \def EMPLOYEES_H
  Declara que "EMPLOYEES_H" está definido na aplicação, significando a já existência do mesmo
*/
#define EMPLOYEES_H
#include "includes.h"

/**
 * \typedef typedef enum Rank
 * @brief Seta o alias "Rank" para o tipo de dado de enumeração enum Rank
 */
/*!
  @brief
  Enumeração dos cargos existentes para um funcionario
*/
typedef enum {
  Receptionist, 
  Maid, 
  Waiter, 
  Manager
} Rank;

/**
 * \typedef typedef struct Employee Employee
 * @brief Seta o alias "Employee" para a estrutura do tipo de dado "struct Employee"
 */
/**
 * \struct Employee
 * @brief Esta é a estrutura do funcionario, que por sua vez é uma arvore binaria, e ela é responsavel por armazenar as informações do funcionario, tal como o id, nome, telefone, cargo, salario, etc
 */
typedef struct Employee {
   /**
    * @name Campos da estrutura
   */
   /*@{*/
   int id; /**< O ID do funcionario */
   char name[55]; /**< O nome do funcionario */
   char phone[25]; /**< O telefone de contato do funcionario */
   Rank rank; /**< O cargo do funcionario */
   float salary; /**< O salario do funcionario */
   /*@}*/

   /**
    * @name Continuação (arvore binaria)
   */
   /*@{*/
   struct Employee *next;  /**< Ponteiro para o proxima elemento da estrutura Employee */
   /*@}*/
} Employee;

//Obter a string referente ao cargo
char *rankName(Rank);

//Obter ID de funcionario valido (se filtro ativado)
int ask_employee_id(int, int);

//Editar funcionario
Employee *editEmployee(Employee*, int);

//Mostras informações do funcionario
Employee *showEmployee(Employee*);

//Retornar funcionario por ID
Employee *getEmployee(int);

//Proc de pesquisar funcionarios
int search_employees();

//Proc de adicionar funcionario
int add_employee();

//Proc de mostrar funcionario
int show_employee();

//Proc de editar funcionario
int edit_employee();

//Proc de deletar funcionario
int del_employee();

/*
   INICIO: Gravar, salvar, carregar, liberar dados do arquivo !
*/
int show_all_employees();

int save_all_employees();

void load_employee(int);

extern int employees_loaded;

int load_all_employees();

void release_employees();
/*
   FIM: Gravar, salvar, carregar, liberar dados do arquivo !
*/

//Mostrar menu
void employee_menu();

#endif
