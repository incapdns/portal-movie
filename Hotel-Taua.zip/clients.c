/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#include "clients.h"
#include "stays.h"

/*!
  @brief
  Ponteiro para o primeiro elemento Struct da arvore binaria
*/
Client *first_client = NULL;

/*!
  @brief
  Ponteiro para o ultimo elemento Struct da arvore binaria
*/
Client *last_client = NULL;

/**@brief
 * Esta função irá solicitar um inteiro, e distinguir entre string literal e numero (int) atravez do atoi. \n 
 * Irá retornar um ID de cliente ou um número valido (>=0) dependendo dos parametros: int registered e int filter \n
 * \warning
 * ask_client_id(1, 1): Irá persistir em um ID de cliente já existente (Se int filter = 1)\n
 * ask_client_id(0, 1): Irá pesistir em um ID de cliente não cadastrado (Se int filter = 1)
 * 
 * Ao informar "P", ira encaminhar para a caixa de pesquisa referente ao procedimento search_clients()
 * 
 * @param [in] registered: Se verdadeiro, printf com a msg: "Insira o ID", se não, "Novo ID"
 * @param [in] filter: Ativa ou desativa o filtro
 * 
 * @retval inteiro: Numero valido (>=0), ou ID de um cliente já existente / disponivel para cadastro
*/
int ask_client_id(int registered, int filter){
   char *msg = registered ? "Insira o ID: " : "Novo ID: ";

   char *redir = registered ? "P" : NULL;
   
   char *msg_warn = registered ? "\nErro: ID de cliente nao existe\n" : "\nErro: ID ja existe\n";

   int err = 0, id;

   do {
      if (err)
         printf("%s", msg_warn);

      id = askValidNumber(msg, redir, &search_clients);
      int found = getClient(id) ? 1 : 0;
      err = registered ? !found : found;
   } while (err && filter);

   return id;
}

/**@brief
 * É a função responsavel por editar um cliente\n
 * Se o parametro int registered = 0, significa edição de cliente recem criada no procedimento add_client()
 * 
 * @param [out] item: Ponteiro para o cliente em questão
 * @param [in] registered: Edição de um cliente já existente ou não ( 1 = já existente, 0 = recem criada )
 * 
 * @retval NULL: Usuario abortou operação de criar/editar cliente recem criada
 * @retval Client*: cliente editado com sucesso
*/
Client *editClient(Client *item, int registered){
   int id = item->id;

   if (registered){
      printf("---- DADOS ANTIGOS ----\n");
      showClient(item);
      printf("\n");
   } else {
      id = ask_client_id(0, 1);
      if(id == 0) return NULL;
   }

   item->id = id;

   setbuf(stdin, NULL);

   printf("Novo nome: ");
   afgets(item->name, 55);

   printf("Novo endereco: ");
   afgets(item->address, 100);

   printf("Novo telefone: ");
   afgets(item->phone, 25);

   if(!registered)
      item->total = item->warn_points = item->win_points = item->points = 0;

   return item;
}

/**@brief
 * É a função responsavel por exibir informações de um cliente\n
 * 
 * @param [out] item: item: O ponteiro do elemento struct Client a ser exibido
 * 
 * @retval Client*: Ponteiro do elemento struct Client
*/
Client *showClient(Client *item){
   printf("ID: %i\n", item->id);
   printf("Nome: %s\n", item->name);
   printf("Endereco: %s\n", item->address);
   printf("Telefone: %s\n", item->phone);
   printf("Pontos: %.3f\n", item->points);

   return item;
}

/**@brief
 * É a função responsavel por retornar um ponteiro de cliente\n
 * Se o ID passado por parametro não pertencer a nenhum cliente, o retorno é NULL
 * 
 * @param [in] id: O ID do cliente a ser consultado
 * 
 * @retval NULL: Este ID de cliente não existe em nenhuma struct Client
 * @retval Client*: Ponteiro do elemento struct Client
*/
Client *getClient(int id){
   Client *curr = first_client;

   while (curr != NULL){
      if (curr->id == id)
         return curr;

      curr = curr->next;
   }

   return NULL;
}

/**@brief
 * Procedimento responsavel por pesquisar e mostrar todos os cliente que atendam o seguinte filtro:\n
 * 1 - Parte do nome do cliente: Mostrar todas os clientes cujo nome contenham a string\n
 * 
 * @retval number: Numero (int) de clientes encontradas
*/
int search_clients(){
   char term[55];

   printf("Nome?: ");
   afgets(term, 55);

   printf("\n---- RESULTADOS ----\n");

   Client *curr = first_client;

   int found = 0;

   while (curr != NULL){
      if (strcasestr(curr->name, term) != NULL){
         showClient(curr);
         printf("\n----------------\n\n");
         found++;
      }

      curr = curr->next;
   }

   return found;
}

/**@brief
 * É o procedimento para iniciar o cadastro de um cliente\n
 * Ele irá solicitar as informações presentes na estrutura Client\n
 * Ao informar Novo ID: 0, a operação é cancelada com o codigo de retorno 2
 *  
 * @retval 0: Falha na operação, ID de cliente não existe
 * @retval 1: Procedimento completado com sucesso
 * @retval 2: Usuário cancelou a operação
*/
int add_client(){
   Client *target;
   Client *prev = last_client;

   if (first_client == NULL)
      target = last_client = first_client = malloc(sizeof(Client));
   else
      target = last_client = last_client->next = malloc(sizeof(Client));

   target->next = NULL;

   Client *item = editClient(target, 0);
   if(item == NULL){
      free(target);

      if(prev)
         prev->next = NULL;
      else
         first_client = prev;

      last_client = prev;

      printf("\nUsuario cancelou a operacao\n");

      return 2;
   }

   return 1;
}

/**@brief
 * É o procedimento para iniciar a exibição de um determinado cliente\n
 * Quando o ID informado não existe, seja ele 0, x ou qualquer outro ID não existente, o codigo de retorno é 0
 *  
 * @retval 0: Falha na operação, ID de cliente não existe
 * @retval 1: Procedimento completado com sucesso
*/
int show_client(){
   int id = ask_client_id(1, 0);

   Client *at = getClient(id);
   if (!at) return 0;

   showClient(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a edição de um cliente\n
 * Quando o ID informado não existe, seja ele 0, x ou qualquer outro ID não existente, o codigo de retorno é 0
 *  
 * @retval 0: Falha na operação, ID de cliente não existe
 * @retval 1: Procedimento completado com sucesso
*/
int edit_client(){
   int id = ask_client_id(1, 0);

   Client *at = getClient(id);
   if (!at) return 0;

   editClient(at, 1);

   return 1;
}

/**@brief
 * É o procedimento para iniciar exclusão de um cliente
 *  
 * @retval 0: Falha na operação, ID de cliente não existe
 * @retval 1: Procedimento completado com sucesso
*/
int del_client(){
   int id = ask_client_id(1, 0);

   Client *at = getClient(id);
   if (!at) return 0;

   if (at == first_client){
      first_client = at->next;
      if(last_client == at)
         last_client = first_client;

      free(at);

      return 1;
   }

   Client *curr = first_client;

   Client *prev;

   while (curr != NULL){
      if (curr->next == at){
         prev = curr;
         break;
      }

      curr = curr->next;
   }

   prev->next = at->next;
   if(at == last_client)
      last_client = prev;

   free(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar exibição da fatura de um cliente, este procedimento realiza uma chamada na função printBill(Client*) referente a definição em Stay
 *  
 * @retval 0: Falha na operação, ID de estadia não existe
 * @retval 1: Procedimento completado com sucesso
*/
int bill_client(){
   int id = ask_client_id(1, 0);

   Client *at = getClient(id);
   if (!at) return 0;

   printf("\nFatura:\n");
   
   printBill(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a exibição de todos os clientes existentes
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int show_all_clients(){
   Client *curr = first_client;

   printf("---- CLIENTES ----\n");

   while (curr != NULL){
      showClient(curr);

      curr = curr->next;

      if (curr)
         printf("\n----------------\n\n");
   }

   return 1;
}

/**@brief
 * Procedimento responsavel por salva toda a arvore binaria de clientes em um arquivo de texto binario, na pasta "./clients"
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int save_all_clients(){
   int i = 0;

   Client *curr = first_client;

   while (curr != NULL){
      char name[20];
      snprintf(name, 20, "clients/%i", i);

      mwrite(name, curr, sizeof(Client), 1);

      curr = curr->next;

      i++;
   }

   char total[10];
   snprintf(total, 10, "%i", i);

   save("clients/total", total);

   return 1;
}

/**@brief
 * Procedimento responsavel por carregar um determinado arquivo de cliente, exemplo:\n
 * 0: carregar a estrutura Client presente no arquivo binario: clients/0
*/
void load_client(int i){
   char name[20];
   snprintf(name, 20, "clients/%i", i);

   Client *target = malloc(sizeof(Client));
   FILE *file = fopen(name, "r");
   fread(target, sizeof(Client), 1, file);
   fclose(file);

   if (first_client == NULL)
      last_client = first_client = target;
   else
      last_client = last_client->next = target;
}

/**@brief
 * Variavel externa global responsavel por informar se os clientes estão carregados ou não\n
 * Se verdadeiro, os clientes ja estão inicializadas, caso contrario não existem clientes, ou falha ao ler o arquivo
*/
int clients_loaded = 0;

/**@brief
 * Procedimento responsavel por carregar toda a arvore binaria de clientes de acordo com as estruturas salvas em um arquivo de texto (binario)
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int load_all_clients(){
   if (clients_loaded) return 0;

   FILE *fp = fopen("clients/total", "r");
   if (fp == NULL) return 0;

   int total = 0;
   fscanf(fp, "%i", &total);
   fclose(fp);

   for (int i = 0; i < total; i++)
      load_client(i);

   if (total)
      last_client->next = NULL;

   clients_loaded = 1;

   return 1;
}

/**@brief
 * Função responsavel por liberar a memoria alocada de todas as struct Client carregadas no sistema
*/
void release_clients(){
   Client *curr = first_client;

   while (curr != NULL){
      Client *temp = curr;
      curr = curr->next;
      free(temp);
   }

   clients_loaded = 0;
}

/**@brief
 * Procedimento responsavel por exibir todos os itens do sub-menu de Cliente.\n\n
 * 0 - Volta ao menu principal\n\n
 * P - Pesquisar - search_clients()\n
 * A - Adicionar cliente - add_client()\n
 * M - Mostrar cliente - show_client()\n
 * E - Editar cliente - edit_client()\n
 * R - Remover cliente - del_client()\n
 * F - Fatura do cliente - bill_client()\n
 * L - Listar todos - show_all_clients()
*/
void client_menu(){
   char option;

   load_all_clients();

   load_all_stays();

   do {
      printf("Voltar: 0\n\n");
      printf("Pesquisar: P\n\n");

      printf("A: Adicionar cliente\n");
      printf("M: Mostrar cliente\n");
      printf("E: Editar cliente\n");
      printf("R: Remover cliente\n");
      printf("F: Fatura do cliente\n");
      printf("L: Listar todos\n\n");

      printf("\nSua opcao: ");

      char buffer[10];
      afgets(buffer, 10);
      sscanf(buffer, "%c", &option);

      if (option == 48) continue;

      int res;

      switch (option){
         case 'P':
            res = search_clients();
            break;

         case 'A':
            res = add_client();
            break;

         case 'M':
            res = show_client();
            break;

         case 'E':
            res = edit_client();
            break;

         case 'R':
            res = del_client();
            break;

         case 'F':
            res = bill_client();
            break;

         case 'L':
            res = show_all_clients();
            break;

         default:
            res = 1;
            printf("Opcao invalida\n");
      }

      if (!res)
         printf("\nErro ao executar a opcao !\n");

      pause();
      clrscr();
   } while (option != 48);

   save_all_clients();
}