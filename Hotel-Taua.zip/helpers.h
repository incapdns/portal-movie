#ifndef HELPERS_H  
#define HELPERS_H
#include "includes.h"

/**
 * \typedef typedef struct Result Result
 * @brief Seta o alias "Result" para a estrutura do tipo de dado "struct Result"
 */
/**
 * \struct Result
 * @brief Esta é a estrutura de Resultado, ela é responsavel por armazenar um vetor de ponteiros referente um determinado tipo dinâmico e a quantidade de itens retornados
 */
typedef struct {
   /**
    * @name Campos da estrutura
   */
   /*@{*/
   int found; /**< É a quantidade de itens contidos no vetor de ponteiros */

   void **itens;
   /*@}*/
} Result;
/** @var Result::itens
 *  É o vetor de itens, neste campo é armazenado o ponteiro do primeiro ponteiro referente a um determinado tipo convertido em void**
 */

extern int diff_year;

//Item está em Result
int inResult(Result *, void *);

//Seta o ano inicial de time_t
void set_diff_year();

//Escrever um arquivo binario
void mwrite(const char *, const void *, int, int);

//Salvar
void save(char *, char *);

//Corrigir string
void fix(char *);

//Verificar DD/MM/YYYY
int checkDate(char *, char *, char *);

//Verificar HH/MM
int checkHour(char *, char *);

//Persistir numero valido
int askValidNumber(char *, char *, int(*cb)(void));

//Diferença em dias
int diffdays(time_t, time_t);
#endif
