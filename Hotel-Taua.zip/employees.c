/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#include "employees.h"

/*!
  @brief
  Ponteiro para o primeiro elemento Struct da arvore binaria
*/
Employee *first_employee = NULL;

/*!
  @brief
  Ponteiro para o ultimo elemento Struct da arvore binaria
*/
Employee *last_employee = NULL;

/**@brief
 * É a função responsavel por retornar a string referente ao cargo do funcionario\n
 * 0: Recepcionista\n
 * 1: Assistente\n
 * 2: Garcom\n
 * 3: Gerente
 * 
 * @param [in] rank: O inteiro contido no ENUM{0,1,2,3}
 * 
 * @retval char*: String referente ao nome do cargo
*/
char *rankName(Rank rank){
   return rank == Receptionist ? "Recepcionista" : (
      rank == Maid ? "Assistente" : (
         rank == Waiter ? "Garcom" : "Gerente"
      )
   );
}

/**@brief
 * Esta função irá solicitar um inteiro, e distinguir entre string literal e numero (int) atravez do atoi. \n 
 * Irá retornar um ID de funcionario ou um número valido (>=0) dependendo dos parametros: int registered e int filter \n
 * \warning
 * ask_employee_id(1, 1): Irá persistir em um ID de funcionario já existente (Se int filter = 1)\n
 * ask_employee_id(0, 1): Irá pesistir em um ID de funcionario não cadastrado (Se int filter = 1)
 * 
 * Ao informar "P", ira encaminhar para a caixa de pesquisa referente ao procedimento search_employees()
 * 
 * @param [in] registered: Se verdadeiro, printf com a msg: "Insira o ID", se não, "Novo ID"
 * @param [in] filter: Ativa ou desativa o filtro
 * 
 * @retval inteiro: Numero valido (>=0), ou ID de um funcionario já existente / disponivel para cadastro
*/
int ask_employee_id(int registered, int filter){
   char *msg = registered ? "Insira o ID: " : "Novo ID: ";
   
   char *redir = registered ? "P" : NULL;
   
   char *msg_warn = registered ? "\nErro: ID de funcionario nao existe\n" : "\nErro: ID ja existe\n";

   int err = 0, id;

   do {
      if (err)
         printf("%s", msg_warn);

      id = askValidNumber(msg, redir, &search_employees);
      int found = getEmployee(id) ? 1 : 0;
      err = registered ? !found : found;
   } while (err && filter);

   return id;
}

/**@brief
 * É a função responsavel por editar um funcionario\n
 * Se o parametro int registered = 0, significa edição de funcionario recem criada no procedimento add_employee()
 * 
 * @param [out] item: Ponteiro para o funcionario em questão
 * @param [in] registered: Edição de um funcionario já existente ou não ( 1 = já existente, 0 = recem criada )
 * 
 * @retval NULL: Usuario abortou operação de criar/editar funcionario recem criada
 * @retval Employee*: funcionario editado com sucesso
*/
Employee *editEmployee(Employee *item, int registered){
   int id = item->id;

   if (registered){
      printf("---- DADOS ANTIGOS ----\n");
      showEmployee(item);
      printf("\n");
   } else {
      id = ask_employee_id(0, 1);
      if(id == 0) return NULL;
   }

   item->id = id;

   setbuf(stdin, NULL);

   printf("Novo nome: ");
   afgets(item->name, 55);

   printf("Novo telefone: ");
   afgets(item->phone, 25);

   printf("\n");

   int err = 0, rank;
   do {
      if (err)
         printf("\nErro: Somente 0 ate 3");

      printf("Opcoes: ");
      printf("0 - Recepcionista, 1 - Assistente, 2 - Garcom, 3 - Gerente\nNovo cargo: ");
      scanf("%i", &rank);
      err = !(rank >= 0 && rank <= 3);
   } while (err);

   setbuf(stdin, NULL);

   item->rank = rank;

   printf("\nNovo salario: ");
   scanf("%f", &item->salary);
   setbuf(stdin, NULL);

   setbuf(stdin, NULL);

   return item;
}

/**@brief
 * É a função responsavel por exibir informações de um funcionario\n
 * 
 * @param [out] item: item: O ponteiro do elemento struct Employee a ser exibido
 * 
 * @retval Employee*: Ponteiro do elemento struct Employee
*/
Employee *showEmployee(Employee *item){
   printf("ID: %i\n", item->id);
   printf("Nome: %s\n", item->name);
   printf("Telefone: %s\n", item->phone);
   printf("Cargo: %s\n", rankName(item->rank));
   printf("Salario: %.2f\n", item->salary);

   return item;
}

/**@brief
 * É a função responsavel por retornar um ponteiro de funcionario\n
 * Se o ID passado por parametro não pertencer a nenhum funcionario, o retorno é NULL
 * 
 * @param [in] id: O ID do funcionario a ser consultado
 * 
 * @retval NULL: Este ID de funcionario não existe em nenhuma struct Employee
 * @retval Employee*: Ponteiro do elemento struct Employee
*/
Employee *getEmployee(int id){
   Employee *curr = first_employee;

   while (curr != NULL){
      if (curr->id == id)
         return curr;

      curr = curr->next;
   }

   return NULL;
}

/**@brief
 * Procedimento responsavel por pesquisar e mostrar todos os funcionarios que atendam o seguinte filtro:\n
 * 1 - Parte do nome do funcionarios: Mostrar todas os funcionarios cujo nome contenham a string\n
 * 
 * @retval number: Numero (int) de funcionarios encontradas
*/
int search_employees(){
   char term[55];

   printf("Nome?: ");
   afgets(term, 55);

   printf("\n---- RESULTADOS ----\n");

   Employee *curr = first_employee;

   int found = 0;

   while (curr != NULL){
      if (strcasestr(curr->name, term) != NULL){
         showEmployee(curr);
         printf("\n----------------\n\n");
         found++;
      }

      curr = curr->next;
   }

   return found;
}

/**@brief
 * É o procedimento para iniciar o cadastro de um funcionario\n
 * Ele irá solicitar as informações presentes na estrutura Employee\n
 * Ao informar Novo ID: 0, a operação é cancelada com o codigo de retorno 2
 *  
 * @retval 0: Falha na operação, ID de funcionario não existe
 * @retval 1: Procedimento completado com sucesso
 * @retval 2: Usuário cancelou a operação
*/
int add_employee(){
   Employee *target;
   Employee *prev = last_employee;

   if (first_employee == NULL)
      target = last_employee = first_employee = malloc(sizeof(Employee));
   else
      target = last_employee = last_employee->next = malloc(sizeof(Employee));

   target->next = NULL;

   Employee *item = editEmployee(target, 0);
   if(item == NULL){
      free(target);

      if(prev)
         prev->next = NULL;
      else
         first_employee = prev;

      last_employee = prev;

      printf("\nUsuario cancelou a operacao\n");
      
      return 2;
   }

   return 1;
}

/**@brief
 * É o procedimento para iniciar a exibição de um determinado funcionario\n
 * Quando o ID informado não existe, seja ele 0, x ou qualquer outro ID não existente, o codigo de retorno é 0
 *  
 * @retval 0: Falha na operação, ID de funcionario não existe
 * @retval 1: Procedimento completado com sucesso
*/
int show_employee(){
   int id = ask_employee_id(1, 0);

   Employee *at = getEmployee(id);
   if (!at) return 0;

   showEmployee(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a edição de um funcionario\n
 * Quando o ID informado não existe, seja ele 0, x ou qualquer outro ID não existente, o codigo de retorno é 0
 *  
 * @retval 0: Falha na operação, ID de funcionario não existe
 * @retval 1: Procedimento completado com sucesso
*/
int edit_employee(){
   int id = ask_employee_id(1, 0);

   Employee *at = getEmployee(id);
   if (!at) return 0;

   editEmployee(at, 1);

   return 1;
}

/**@brief
 * É o procedimento para iniciar exclusão de um funcionario
 *  
 * @retval 0: Falha na operação, ID de funcionario não existe
 * @retval 1: Procedimento completado com sucesso
*/
int del_employee(){
   int id = ask_employee_id(1, 0);

   Employee *at = getEmployee(id);
   if (!at) return 0;

   if (at == first_employee){
      first_employee = at->next;
      if(last_employee == at)
         last_employee = first_employee;

      free(at);

      return 1;
   }

   Employee *curr = first_employee;

   Employee *prev = NULL;

   while (curr != NULL){
      if (curr->next == at){
         prev = curr;
         break;
      }

      curr = curr->next;
   }

   prev->next = at->next;
   if(at == last_employee)
      last_employee = prev;

   free(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a exibição de todos os funcionarios existentes
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int show_all_employees(){
   Employee *curr = first_employee;

   printf("---- FUNCIONARIOS ----\n");

   while (curr != NULL){
      showEmployee(curr);

      curr = curr->next;

      if (curr)
         printf("\n----------------\n\n");
   }

   return 1;
}

/**@brief
 * Procedimento responsavel por salva toda a arvore binaria de funcionarios em um arquivo de texto binario, na pasta "./employees"
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int save_all_employees(){
   int i = 0;

   Employee *curr = first_employee;

   while (curr != NULL){
      char name[20];
      snprintf(name, 20, "employees/%i", i);

      mwrite(name, curr, sizeof(Employee), 1);

      curr = curr->next;

      i++;
   }

   char total[10];
   snprintf(total, 10, "%i", i);

   save("employees/total", total);

   return 1;
}

/**@brief
 * Procedimento responsavel por carregar um determinado arquivo de funcionario, exemplo:\n
 * 0: carregar a estrutura Employee presente no arquivo binario: employees/0
*/
void load_employee(int i){
   char name[20];
   snprintf(name, 20, "employees/%i", i);

   Employee *target = malloc(sizeof(Employee));
   FILE *file = fopen(name, "r");
   fread(target, sizeof(Employee), 1, file);
   fclose(file);

   if (first_employee == NULL)
      last_employee = first_employee = target;
   else
      last_employee = last_employee->next = target;
}

/**@brief
 * Variavel externa global responsavel por informar se os funcionarios estão carregados ou não\n
 * Se verdadeiro, os funcionarios ja estão inicializadas, caso contrario não existem funcionarios, ou falha ao ler o arquivo
*/
int employees_loaded = 0;

/**@brief
 * Procedimento responsavel por carregar toda a arvore binaria de funcionarios de acordo com as estruturas salvas em um arquivo de texto (binario)
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int load_all_employees(){
   if (employees_loaded) return 0;

   FILE *fp = fopen("employees/total", "r");
   if (fp == NULL) return 0;

   int total = 0;
   fscanf(fp, "%i", &total);
   fclose(fp);

   for (int i = 0; i < total; i++)
      load_employee(i);

   if (total)
      last_employee->next = NULL;

   employees_loaded = 1;

   return 1;
}

/**@brief
 * Função responsavel por liberar a memoria alocada de todas as struct Employee carregadas no sistema
*/
void release_employees(){
   Employee *curr = first_employee;

   while (curr != NULL){
      Employee *temp = curr;
      curr = curr->next;
      free(temp);
   }

   employees_loaded = 0;
}

/**@brief
 * Procedimento responsavel por exibir todos os itens do sub-menu de Funcionario.\n\n
 * 0 - Volta ao menu principal\n\n
 * P - Pesquisar - search_employees()\n
 * A - Adicionar funcionario - add_employee()\n
 * M - Mostrar funcionario - show_employee()\n
 * E - Editar funcionario - edit_employee()\n
 * R - Remover funcionario - del_employee()\n
 * L - Listar todos - show_all_employees()
*/
void employee_menu(){
   char option;

   load_all_employees();

   do {
      printf("Voltar: 0\n\n");
      printf("Pesquisar: P\n\n");

      printf("A: Adicionar funcionario\n");
      printf("M: Mostrar funcionario\n");
      printf("E: Editar funcionario\n");
      printf("R: Remover funcionario\n");
      printf("L: Listar todos\n\n");

      printf("\nSua opcao: ");

      char buffer[10];
      afgets(buffer, 10);
      sscanf(buffer, "%c", &option);

      if (option == 48)
         continue;

      int res;

      switch (option){
         case 'P':
            res = search_employees();
            break;

         case 'A':
            res = add_employee();
            break;

         case 'M':
            res = show_employee();
            break;

         case 'E':
            res = edit_employee();
            break;

         case 'R':
            res = del_employee();
            break;

         case 'L':
            res = show_all_employees();
            break;

         default:
            res = 1;
            printf("Opcao invalida\n");
      }

      if (!res)
         printf("\nErro ao executar a opcao !\n");

      pause();
      clrscr();
   } while (option != 48);

   save_all_employees();
}