/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#include "stays.h"
#include "settings.h"

/*!
  @brief
  Ponteiro para o primeiro elemento Struct da arvore binaria
*/
Stay *first_stay = NULL;

/*!
  @brief
  Ponteiro para o ultimo elemento Struct da arvore binaria
*/
Stay *last_stay = NULL;

/**@brief
 * Esta função irá solicitar um inteiro, e distinguir entre string literal e numero (int) atravez do atoi. \n 
 * Irá retornar um ID de estadia ou um número valido (>=0) dependendo dos parametros: int registered e int filter \n
 * \warning
 * ask_stay_id(1, 1): Irá persistir em um ID de estadia já existente (Se int filter = 1)\n
 * ask_stay_id(0, 1): Irá pesistir em um ID de estadia não cadastrado (Se int filter = 1)
 * 
 * Ao informar "P", ira encaminhar para a caixa de pesquisa referente ao procedimento search_stays()
 * 
 * @param [in] registered: Se verdadeiro, printf com a msg: "Insira o ID", se não, "Novo ID"
 * @param [in] filter: Ativa ou desativa o filtro
 * 
 * @retval inteiro: Numero valido (>=0), ou ID de uma estadia já existente / disponivel para cadastro
*/
int ask_stay_id(int registered, int filter){
   char *msg = registered ? "Insira o ID: " : "Novo ID: ";

   char *redir = registered ? "P" : NULL;
   
   char *msg_warn = registered ? "\nErro: ID de estadia nao existe\n" : "\nErro: ID ja existe\n";

   int err = 0, id;

   do {
      if (err)
         printf("%s", msg_warn);

      id = askValidNumber(msg, redir, &search_stays);
      int found = getStay(id) ? 1 : 0;
      err = registered ? !found : found;
   } while (err && filter);

   return id;
}

/**@brief
 * Esta função retorna um struct Result contendo as estadias cuja data de saida for menor ou igual ao parametro time_t end com execção do Stay *exception
 * 
 * @param [in] end: Objeto referente a data final
 * @param [out] exception: Estrutura Stay* a ser ignorada nos resultados
 * 
 * @retval Result: Uma estrutura Result com a conversão de tipo .itens void** para Stay**
*/
Result getStaysExpired(time_t end, Stay *exception){
   int usize = sizeof(Stay *), size = usize;
   Stay **stays = malloc(size);

   int total = 0;

   Stay *curr = first_stay;

   while (curr != NULL){
      int expired = difftime(end, curr->end) >= 0;

      if (curr != exception && expired){
         if (!total)
            stays[0] = curr;
         else {
            size += usize;
            stays = realloc(stays, size);
            stays[total] = curr;
         }

         total++;
      }

      curr = curr->next;
   }

   if (!total)
      free(stays);

   void **itens = (void**) stays;

   Result res = {.found = total, .itens = itens};

   return res;
}


/**@brief
 * Procedimento responsavel por mostrar as informações das estadias vencidas que estão presentes na estrutura Result como parametro\n
 * Caso o numero de itens contidos na estrutura Result.itens seja 0, o procendimento é anulado\n
 * Caso contrario, alem de exibir as informações é solicitado um menu: [1] - Cancelar todas, [0] Ignorar
 * 
 * @param [in] query: A estrutura Result que contem as estadias vencidas .itens Stay**
*/
void warnStaysExpired(Result query){   
   Stay **stays = (Stay**) query.itens;

   if(query.found)
   {
      printf("Sera necessario cancelar todas as vencidas p/ concluir\n");
      printf("Mais estadias vencidas: \n\n");

      for(int i = 0; i < query.found; i++){
         showStay(stays[i]);
         printf("\n----------------\n\n");
      }

      printf("[1]: Cancelar todas, [0]: Ignorar, nao cancelar nenhuma\n");
   }
}

/**@brief
 * Esta função retorna um struct Result contendo as estadias de um determinado cliente, e o numero de estadias encontrado
 * 
 * @param [out] item: Ponteiro para o objeto Client
 * 
 * @retval Result: Uma estrutura Result com a conversão de tipo .itens void** para Stay**
*/
Result getStaysByClient(Client *item){
   int usize = sizeof(Stay *), size = usize;
   Stay **stays = malloc(size);

   int total = 0;

   Stay *curr = first_stay;

   while (curr != NULL){
      Client *client = getClient(curr->client_id);

      if (client == item){
         if (!total)
            stays[0] = curr;
         else {
            size += usize;
            stays = realloc(stays, size);
            stays[total] = curr;
         }

         total++;
      }

      curr = curr->next;
   }

   if (!total)
      free(stays);

   void **itens = (void**) stays;

   Result res = {.found = total, .itens = itens};

   return res;
}

/**@brief
 * Esta função irá solicitar uma data no formato DD/MM/YYYY HH:MM \n 
 * Se is_start for verdadeiro, ira persistir em valores HH:MM >= 14
 * 
 * @param [in] type: Se verdadeiro, printf com a msg: "Insira a data", se não, "Nova data"
 * @param [in] is_start: É a data de entrada ou saida ( 1 = entrada,  0 = saida)
 * 
 * @retval inteiro: Um objeto time_t referente a data (string) informada
*/
time_t ask_date(int type, int is_start){
   char *msg = type == 1 ? "Insira a data: " : "Nova data: ";
   char buffer[100];

   time_t now;
   time(&now);

   struct tm *fd = localtime(&now);

   fd->tm_hour = fd->tm_min = fd->tm_sec = 0;

   int err = 0, v_hour = 1;

   do {
      if(err)
         printf("\nErro: Data invalida, formato: dd/mm/YYYY HH:MM\n");
      else if(!v_hour)
         printf("\nErro: Data de entrada a partir das 14:00!\n");

      printf("%s", msg);
      afgets(buffer, 100);

      char d[3], m[3], y[5];
      char hour[3], min[3];

      sscanf(buffer, "%2s/%2s/%4s %2s:%2s", d, m, y, hour, min);

      err = !checkDate(d, m, y) || !checkHour(hour, min);
      if (err) continue;

      v_hour = is_start ? atoi(hour) >= 14 : 1;
      if(!v_hour) continue;

      fd->tm_year = atoi(y) - diff_year;
      fd->tm_mon = atoi(m) - 1;
      fd->tm_mday = atoi(d);

      fd->tm_hour = atoi(hour);
      fd->tm_min = atoi(min);
   } while (err || !v_hour);

   return mktime(fd);
}

/**@brief
 * É a função responsavel por editar uma estadia\n
 * Se o parametro int registered = 0, significa edição de estadia recem criada no procedimento add_stay()
 * 
 * @param [out] item: Ponteiro para a estadia em questão
 * @param [in] registered: Edição de uma estadia já existente ou não ( 1 = já existente, 0 = recem criada )
 * 
 * @retval NULL: Usuario abortou operação de criar/editar estadia recem criada
 * @retval Stay*: Estadia editada com sucesso
*/
Stay *editStay(Stay *item, int registered){
   int err = 0, id = item->id;

   if (registered){
      printf("---- DADOS ANTIGOS ----\n");
      showStay(item);
   } else {
      id = ask_stay_id(0, 1);
      if(id == 0) return NULL;
   }

   item->id = id;

   setbuf(stdin, NULL);

   int oguests = item->guests;
   int ostart = item->start;
   int oend = item->end;

   if(registered){
      Room *room = getRoom(item->room_id);
      room->status = Available;
   }

   printf("\nQuarto\n");
   Room *room;
   do {
      if (err)
         printf("\nErro: Quarto nao disponivel !\n");

      int room_id = ask_room_id(1, 1);
      room = getRoom(room_id);
      err = room->status == NotAvailable;
   } while (err);
   item->room_id = room->id;

   room->status = NotAvailable;

   do {
      if(err)
         printf("\nErro: Maximo de %i hospedes no quarto", room->max);

      printf("\nNovo num hospedes: ");
      scanf("%i", &item->guests);
      setbuf(stdin, NULL);
      err = item->guests > room->max;
   } while(err);
   int dguests = oguests != item->guests;

   printf("\nData do Sistema: %s\n", b_system_date);

   printf("\nEntrada\n");
   do {
      if(err)
         printf("\nErro: Precisa ser maior ou igual a Data do Sistema!\n");
      
      item->start = ask_date(registered, 1);
      err = difftime(item->start, date) < 0;
   } while (err);
   double dstart = difftime(item->start, ostart);

   printf("\nSaida\n");
   do {
      if(err)
         printf("\nErro: Minimo de um dia na estalagem !\n");

      item->end = ask_date(registered, 0);
      err = diffdays(item->end, item->start) <= 0;
   } while(err);
   double dend = difftime(item->end, oend);

   printf("\nCliente\n");
   item->client_id = ask_client_id(1, 1);

   //Caso haja mudança no numero de dias ou qtd de hospedes.
   if(dguests || dstart || dend)
      item->s_room_price = room->price;

   setbuf(stdin, NULL);

   return item;
}

/**@brief
 * É a função responsavel por exibir informações de uma estadia\n
 * 
 * @param [out] item: item: O ponteiro do elemento struct Stay a ser exibido
 * 
 * @retval Stay*: Ponteiro do elemento struct Stay
*/
Stay *showStay(Stay *item){
   char start[100], end[100];

   strftime(start, 100, "%d/%m/%Y %H:%M", localtime(&item->start));
   strftime(end, 100, "%d/%m/%Y %H:%M", localtime(&item->end));

   Client *client = getClient(item->client_id);

   printf("ID: %i\n", item->id);
   printf("N de Hospedes: %i\n", item->guests);
   printf("Data entrada: %s\n", start);
   printf("Data saida: %s\n", end);
   printf("Cliente: %s (%i)\n", client->name, client->id);
   printf("Quarto: %i\n", item->room_id);
   printf("Dias: %i\n", diffdays(item->end, item->start));

   return item;
}


/**@brief
 * É a função responsavel por retornar um ponteiro de estadia\n
 * Se o ID passado por parametro não pertencer a nenhuma estadia, o retorno é NULL
 * 
 * @param [in] id: O ID da estadia a ser consultado
 * 
 * @retval NULL: Este ID de estadia não existe em nenhuma struct Stay
 * @retval Stay*: Ponteiro do elemento struct Stay
*/
Stay *getStay(int id){
   Stay *curr = first_stay;

   while (curr != NULL){
      if (curr->id == id)
         return curr;

      curr = curr->next;
   }

   return NULL;
}

/**@brief
 * Função responsavel por remover uma estadia
 * 
 * @param [out] item: O ponteiro do elemento struct Stay a ser excluido
 *  
 * @retval 1: Estadia deletada com sucesso
*/
int delStay(Stay *item){
   Room *room = getRoom(item->room_id);
   room->status = Available;

   if (item == first_stay){
      first_stay = item->next;
      if(last_stay == item)
         last_stay = first_stay;

      free(item);

      return 1;
   }

   Stay *curr = first_stay;

   Stay *prev = NULL;

   while (curr != NULL){
      if (curr->next == item){
         prev = curr;
         break;
      }

      curr = curr->next;
   }

   prev->next = item->next;
   if(item == last_stay)
      last_stay = prev;

   free(item);

   return 1;
}

/**@brief
 * Procedimento responsavel por exibir toda a fatura de um determinada cliente, ele mostra o valor total a ser pago, desconto, pontos que podem ser usados, quantos pontos irá ser ganho, etc.
 * 
 * @param [out] item: O ponteiro do cliente em questão
*/
void printBill(Client *item){
   item->total = item->win_points = 0;

   Result query = getStaysByClient(item);

   if(query.found){
      Stay **stays = (Stay**) query.itens;

      for(int i = 0; i < query.found; i++){
         Stay *stay = stays[i];

         Client *client = getClient(stay->client_id);

         int days = diffdays(stay->end, stay->start);

         float price = 1 * stay->s_room_price * days;

         client->total += price;

         client->win_points += (10 * days);
      }

      free(stays);
   }

   float minus = 0, warn_pts = 0;

   if(item->points > 0){
      warn_pts = item->total / discount;
      if(warn_pts > item->points) 
         warn_pts = item->points;
      
      minus = discount * warn_pts;
   }

   printf("Cliente: %s (%i)\n", item->name, item->id);
   printf("Nome: %s\n", item->name);
   printf("Total Bruto: R$ %.2f\n", item->total);
   printf("Pts Usados: %.3f\n", warn_pts);
   printf("Desconto: R$ %.2f\n", minus);
   printf("Total Final: R$ %.2f\n", item->total - minus);
   printf("Ganho Pts: %i\n", item->win_points);

   item->warn_points = warn_pts;
}

/**@brief
 * Procedimento responsavel por pesquisar e mostrar estadias que atendam a 2 possiveis filtros:\n
 * 1 - Parte do nome do cliente: Mostrar todas as estadias cujo nome do cliente contenham a string\n
 * 2 - ID do quarto: Mostra a estadia cujo ID do quarto é o informado.
 * 
 * @retval number: Numero (int) de estadias encontradas
*/
int search_stays(){
   int option, found;

   printf("\nTipo de filtro: \n");
   printf("1: Nome cliente, 2: ID Quarto\n");
   printf("Sua opcao: ");
   scanf("%i", &option);
   setbuf(stdin, NULL);

   setbuf(stdin, NULL);

   Stay *curr = first_stay;

   int room_id;
   char term[55];

   char *msg = option == 1 ? "Parte do nome: " : "ID do quarto: ";
   printf("%s", msg);

   if (option == 1){
      afgets(term, 55);
   } else
      scanf("%i", &room_id);

   setbuf(stdin, NULL);

   printf("\n---- RESULTADOS ----\n");

   while (curr != NULL){
      Client *client = getClient(curr->client_id);

      if (option == 1 && strcasestr(client->name, term)){
         showStay(curr);
         printf("\n----------------\n\n");
         found++;
      } else if (option == 2 && curr->room_id == room_id){
         showStay(curr);
         printf("\n----------------\n\n");

         return 1;
      }

      curr = curr->next;
   }

   return found;
}

/**@brief
 * É o procedimento para iniciar o cadastro de uma estadia\n
 * Ele irá solicitar as informações presentes na estrutura Stay\n
 * Ao informar Novo ID: 0, a operação é cancelada com o codigo de retorno 2
 *  
 * @retval 0: Falha na operação, ID de estadia não existe
 * @retval 1: Procedimento completado com sucesso
 * @retval 2: Usuário cancelou a operação
*/
int add_stay(){
   if (first_client == NULL) return 0;

   Result query = getAvailableRooms();

   Room **rooms = (Room**) query.itens;

   if(query.found)
      free(rooms);
   else
      return 0;

   Stay *target;
   Stay *prev = last_stay;

   if (first_stay == NULL)
      target = last_stay = first_stay = malloc(sizeof(Stay));
   else
      target = last_stay = last_stay->next = malloc(sizeof(Stay));

   target->next = NULL;

   Stay *item = editStay(target, 0);
   if(item == NULL){
      free(target);

      if(prev)
         prev->next = NULL;
      else
         first_stay = prev;

      last_stay = prev;

      printf("\nUsuario cancelou a operacao\n");
      
      return 2;
   }

   return 1;
}

/**@brief
 * É o procedimento para iniciar a exibição de uma determinada estadia\n
 * Quando o ID informado não existe, seja ele 0, x ou qualquer outro ID não existente, o codigo de retorno é 0
 *  
 * @retval 0: Falha na operação, ID de estadia não existe
 * @retval 1: Procedimento completado com sucesso
*/
int show_stay(){
   int id = ask_stay_id(1, 0);

   Stay *at = getStay(id);
   if (!at) return 0;

   showStay(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a edição de uma estadia\n
 * Quando o ID informado não existe, seja ele 0, x ou qualquer outro ID não existente, o codigo de retorno é 0
 *  
 * @retval 0: Falha na operação, ID de estadia não existe
 * @retval 1: Procedimento completado com sucesso
*/
int edit_stay(){
   int id = ask_stay_id(1, 0);

   Stay *at = getStay(id);
   if (!at) return 0;

   editStay(at, 1);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a conclusão / dar baixa em uma estadia
 *  
 * @retval 0: Falha na operação, ID de estadia não existe
 * @retval 1: Procedimento completado com sucesso
 * @retval 2: Usuário cancelou a operação
*/
int close_stay(){
   int id = ask_stay_id(1, 0);

   Stay *at = getStay(id);
   if (!at) return 0;

   printf("\n---- ESTADIA ----\n");
   showStay(at);
   printf("\n----------------\n\n");

   int check = check_expired_stays(at->end, at);
   if(check == 2) return 2;

   delStay(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar exclusão de uma estadia (diferente de concluir)
 *  
 * @retval 0: Falha na operação, ID de estadia não existe
 * @retval 1: Procedimento completado com sucesso
*/
int del_stay(){
   int id = ask_stay_id(1, 0);

   Stay *at = getStay(id);
   if (!at) return 0;

   delStay(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a exibição de todas as estadias existentes
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int show_all_stays(){
   Stay *curr = first_stay;

   printf("---- ESTADIAS ----\n");

   while (curr != NULL){
      showStay(curr);

      curr = curr->next;

      if (curr)
         printf("\n----------------\n\n");
   }

   return 1;
}

/**@brief
 * Procedimento responsavel por salva toda a arvore binaria de estadias em um arquivo de texto binario, na pasta "./stays"
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int save_all_stays(){
   int i = 0;

   Stay *curr = first_stay;

   while (curr != NULL){
      char name[20];
      snprintf(name, 20, "stays/%i", i);

      mwrite(name, curr, sizeof(Stay), 1);

      curr = curr->next;

      i++;
   }

   char total[10];
   snprintf(total, 10, "%i", i);

   save("stays/total", total);

   save_all_rooms();

   return 1;
}

/**@brief
 * Procedimento responsavel por carregar um determinado arquivo de estadia, exemplo:\n
 * 0: carregar a estrutura Stay presente no arquivo binario: stays/0
*/
void load_stay(int i){
   char name[20];
   snprintf(name, 20, "stays/%i", i);

   Stay *target = malloc(sizeof(Stay));
   FILE *file = fopen(name, "r");
   fread(target, sizeof(Stay), 1, file);
   fclose(file);

   if (first_stay == NULL)
      last_stay = first_stay = target;
   else
      last_stay = last_stay->next = target;
}

/**@brief
 * Variavel externa global responsavel por informar se as estadias estão carregados ou não\n
 * Se verdadeiro, as estadias ja estão inicializadas, caso contrario não existem estadias, ou falha ao ler o arquivo
*/
int stays_loaded = 0;

/**@brief
 * Procedimento responsavel por carregar toda a arvore binaria de estadias de acordo com as estruturas salvas em um arquivo de texto (binario)
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int load_all_stays(){
   if (stays_loaded)
      return 0;

   FILE *fp = fopen("stays/total", "r");
   if (fp == NULL)
      return 0;

   int total = 0;
   fscanf(fp, "%i", &total);
   fclose(fp);

   for (int i = 0; i < total; i++)
      load_stay(i);

   if (total)
      last_stay->next = NULL;

   stays_loaded = 1;

   load_all_clients();

   load_all_rooms();

   return 1;
}

/**@brief
 * Função responsavel por liberar a memoria alocada de todas as struct Stay carregadas no sistema
*/
void release_stays(){
   Stay *curr = first_stay;

   while (curr != NULL){
      Stay *temp = curr;
      curr = curr->next;
      free(temp);
   }

   stays_loaded = 0;
}

/**@brief
 * Procedimento responsavel por exibir todos os itens do sub-menu de Estadia.\n\n
 * 0 - Volta ao menu principal\n\n
 * P - Pesquisar - search_stays()\n
 * A - Adicionar estadia - add_stay()\n
 * M - Mostrar estadia - show_stay()\n
 * E - Editar estadia - edit_stay()\n
 * C - Concluir estadia - close_stay()\n
 * R - Remover estadia - del_stay()\n
 * L - Listar todas - show_all_stays()
*/
void stay_menu(){
   char option;

   load_all_stays();

   do {
      printf("Voltar: 0\n\n");
      printf("Pesquisar: P\n\n");

      printf("A: Adicionar estadia\n");
      printf("M: Mostrar estadia\n");
      printf("E: Editar estadia\n");
      printf("C: Concluir (dar baixa) estadia\n");
      printf("R: Remover estadia\n");
      printf("L: Listar todas\n\n");

      printf("\nSua opcao: ");

      char buffer[10];
      afgets(buffer, 10);
      sscanf(buffer, "%c", &option);

      if (option == 48) continue;

      int res;

      switch (option){
         case 'P':
            res = search_stays();
            break;

         case 'A':
            res = add_stay();
            break;

         case 'M':
            res = show_stay();
            break;

         case 'E':
            res = edit_stay();
            break;

         case 'C':
            res = close_stay();
            break;

         case 'R':
            res = del_stay();
            break;

         case 'L':
            res = show_all_stays();
            break;

         default:
            res = 1;
            printf("Opcao invalida\n");
      }

      if (!res)
         printf("\nErro ao executar a opcao !\n");

      if (!res && option == 'A')
         printf("\nNao existem quartos disponiveis ou clientes cadastrados !\n");

      pause();
      clrscr();
   } while (option != 48);

   save_all_stays();
}