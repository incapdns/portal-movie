#ifndef INCLUDES_H  
#define INCLUDES_H

#if defined _WIN32 || defined __MINGW32__
#include <shlwapi.h>
#define strcasestr StrStrIA
#define clrscr() system("cls")
#define pause()  \
   printf("\n"); \
   system("pause");
#else
#define clrscr() printf("\e[1;1H\e[2J")
#define pause() \
   getchar(); \
   getchar();
#endif

#define afgets(buffer,size) \
   fgets(buffer, size, stdin); \
   fix(buffer); \
   setbuf(stdin, NULL);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "helpers.h"
#endif