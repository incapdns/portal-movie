/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#include "rooms.h"

/*!
  @brief
  Ponteiro para o primeiro elemento Struct da arvore binaria
*/
Room *first_room = NULL;

/*!
  @brief
  Ponteiro para o ultimo elemento Struct da arvore binaria
*/
Room *last_room = NULL;

/**@brief
 * É a função responsavel por retornar a string referente ao status do quarto\n
 * 0: Nao Disponivel\n
 * 1: Disponivel\n
 * 
 * @param [in] status: O inteiro contido no ENUM{0,1}
 * 
 * @retval char*: String referente ao nome do cargo
*/
char *statusName(Status status){
   return status == Available ? "Disponivel" : "Nao Disponivel";
}

/**@brief
 * Esta função irá solicitar um inteiro, e distinguir entre string literal e numero (int) atravez do atoi. \n 
 * Irá retornar um ID de quarto ou um número valido (>=0) dependendo dos parametros: int registered e int filter \n
 * \warning
 * ask_room_id(1, 1): Irá persistir em um ID de quarto já existente (Se int filter = 1)\n
 * ask_room_id(0, 1): Irá pesistir em um ID de quarto não cadastrado (Se int filter = 1)
 * 
 * Ao informar "P", ira encaminhar para a caixa de quartos disponiveis referente ao procedimento show_availables()
 * 
 * @param [in] registered: Se verdadeiro, printf com a msg: "Insira o ID", se não, "Novo ID"
 * @param [in] filter: Ativa ou desativa o filtro
 * 
 * @retval inteiro: Numero valido (>=0), ou ID de um quarto já existente / disponivel para cadastro
*/
int ask_room_id(int registered, int filter){
   char *msg = registered ? "Insira o ID: " : "Novo ID: ";

   char *redir = registered ? "P" : NULL;
   
   char *msg_warn = registered ? "\nErro: ID de quarto nao existe\n" : "\nErro: ID ja existe\n";

   int err = 0, id;

   do {
      if (err)
         printf("%s", msg_warn);

      id = askValidNumber(msg, redir, &show_availables);
      int found = getRoom(id) ? 1 : 0;
      err = registered ? !found : found;
   } while (err && filter);

   return id;
}

/**@brief
 * Esta função retorna um struct Result contendo todos os quartos disponiveis, cujo Room::status é um inteiro 1
 * 
 * @retval Result: Uma estrutura Result com a conversão de tipo .itens void** para Room**
*/
Result getAvailableRooms(){
   int usize = sizeof(Room *), size = usize;
   Room **rooms = malloc(size);

   int total = 0;

   Room *curr = first_room;

   while (curr != NULL){
      if (curr->status == Available){
         if (!total)
            rooms[0] = curr;
         else {
            size += usize;
            rooms = realloc(rooms, size);
            rooms[total] = curr;
         }

         total++;
      }

      curr = curr->next;
   }

   if (!total)
      free(rooms);

   void **itens = (void**) rooms;

   Result res = {.found = total, .itens = itens};

   return res;
}

/**@brief
 * É a função responsavel por editar um quarto\n
 * Se o parametro int registered = 0, significa edição de quarto recem criada no procedimento add_room()
 * 
 * @param [out] item: Ponteiro para o quarto em questão
 * @param [in] registered: Edição de um quarto já existente ou não ( 1 = já existente, 0 = recem criado )
 * 
 * @retval NULL: Usuario abortou operação de criar/editar quarto recem criada
 * @retval Room*: quarto editado com sucesso
*/
Room *editRoom(Room *item, int registered){
   int id = item->id;

   if (registered){
      printf("---- DADOS ANTIGOS ----\n");
      showRoom(item);
      printf("\n");
   } else {
      id = ask_room_id(0, 1);
      if(id == 0) return NULL;
      
      item->status = Available;
   }

   setbuf(stdin, NULL);

   item->id = id;

   printf("Nova capacidade: ");
   scanf("%i", &item->max);
   setbuf(stdin, NULL);

   printf("Novo Preco: ");
   scanf("%f", &item->price);
   setbuf(stdin, NULL);

   setbuf(stdin, NULL);

   return item;
}

/**@brief
 * É a função responsavel por exibir informações de um quarto\n
 * 
 * @param [out] item: item: O ponteiro do elemento struct Room a ser exibido
 * 
 * @retval Room*: Ponteiro do elemento struct Room
*/
Room *showRoom(Room *item){
   printf("ID: %i\n", item->id);
   printf("Capacidade: %i\n", item->max);
   printf("Preco: %.2f\n", item->price);
   printf("Status: %s\n", statusName(item->status));

   return item;
}

/**@brief
 * É a função responsavel por retornar um ponteiro de quarto\n
 * Se o ID passado por parametro não pertencer a nenhum quarto, o retorno é NULL
 * 
 * @param [in] id: O ID do quarto a ser consultado
 * 
 * @retval NULL: Este ID de quarto não existe em nenhuma struct Room
 * @retval Room*: Ponteiro do elemento struct Room
*/
Room *getRoom(int id){
   Room *curr = first_room;

   while (curr != NULL){
      if (curr->id == id)
         return curr;

      curr = curr->next;
   }

   return NULL;
}

/**@brief
 * Procedimento responsavel por pesquisar e mostrar todos os quartos que estejam disponiveis, cujo Room::status seja um inteiro 1
 * 
 * @retval number: Numero (int) de quartos encontradas
*/
int show_availables(){
   Result query = getAvailableRooms();

   printf("---- DISPONIVEIS ----\n");

   Room **rooms = (Room**) query.itens;

   for (int i = 0; i < query.found; i++){
      showRoom(rooms[i]);
      printf("\n----------------\n\n");
   }

   if(query.found)
      free(rooms);

   return query.found;
}

/**@brief
 * É o procedimento para iniciar o cadastro de um quarto\n
 * Ele irá solicitar as informações presentes na estrutura Room\n
 * Ao informar Novo ID: 0, a operação é cancelada com o codigo de retorno 2
 *  
 * @retval 0: Falha na operação, ID de quarto não existe
 * @retval 1: Procedimento completado com sucesso
 * @retval 2: Usuário cancelou a operação
*/
int add_room(){
   Room *target;
   Room *prev = last_room;

   if (first_room == NULL)
      target = last_room = first_room = malloc(sizeof(Room));
   else
      target = last_room = last_room->next = malloc(sizeof(Room));

   target->next = NULL;

   Room *item = editRoom(target, 0);
   if(item == NULL){
      free(target);

      if(prev)
         prev->next = NULL;
      else
         first_room = prev;

      last_room = prev;

      printf("\nUsuario cancelou a operacao\n");
      
      return 2;
   }

   return 1;
}

/**@brief
 * É o procedimento para iniciar a exibição de um determinado quarto\n
 * Quando o ID informado não existe, seja ele 0, x ou qualquer outro ID não existente, o codigo de retorno é 0
 *  
 * @retval 0: Falha na operação, ID de quarto não existe
 * @retval 1: Procedimento completado com sucesso
*/
int show_room(){
   int id = ask_room_id(1, 0);

   Room *at = getRoom(id);
   if (!at) return 0;

   showRoom(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a edição de um quarto\n
 * Quando o ID informado não existe, seja ele 0, x ou qualquer outro ID não existente, o codigo de retorno é 0
 *  
 * @retval 0: Falha na operação, ID de quarto não existe
 * @retval 1: Procedimento completado com sucesso
*/
int edit_room(){
   int id = ask_room_id(1, 0);

   Room *at = getRoom(id);
   if (!at) return 0;

   editRoom(at, 1);

   return 1;
}

/**@brief
 * É o procedimento para iniciar exclusão de um quarto
 *  
 * @retval 0: Falha na operação, ID de quarto não existe
 * @retval 1: Procedimento completado com sucesso
*/
int del_room(){
   int id = ask_room_id(1, 0);

   Room *at = getRoom(id);
   if (!at) return 0;

   if (at == first_room){
      first_room = at->next;
      if(last_room == at)
         last_room = first_room;

      free(at);

      return 1;
   }

   Room *curr = first_room;

   Room *prev = NULL;

   while (curr != NULL) {
      if (curr->next == at){
         prev = curr;
         break;
      }

      curr = curr->next;
   }

   prev->next = at->next;
   if(at == last_room)
      last_room = prev;

   free(at);

   return 1;
}

/**@brief
 * É o procedimento para iniciar a exibição de todos os quartos existentes
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int show_all_rooms(){
   Room *curr = first_room;

   printf("---- QUARTOS ----\n");

   while (curr != NULL){
      showRoom(curr);

      curr = curr->next;

      if (curr)
         printf("\n----------------\n\n");
   }

   return 1;
}

/**@brief
 * Procedimento responsavel por salva toda a arvore binaria de quartos em um arquivo de texto binario, na pasta "./rooms"
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int save_all_rooms(){
   int i = 0;

   Room *curr = first_room;

   while (curr != NULL){
      char name[20];
      snprintf(name, 20, "rooms/%i", i);

      mwrite(name, curr, sizeof(Room), 1);

      curr = curr->next;

      i++;
   }

   char total[10];
   snprintf(total, 10, "%i", i);

   save("rooms/total", total);

   return 1;
}

/**@brief
 * Procedimento responsavel por carregar um determinado arquivo de quarto, exemplo:\n
 * 0: carregar a estrutura Room presente no arquivo binario: rooms/0
*/
void load_room(int i){
   char name[20];
   snprintf(name, 20, "rooms/%i", i);

   Room *target = malloc(sizeof(Room));
   FILE *file = fopen(name, "r");
   fread(target, sizeof(Room), 1, file);
   fclose(file);

   if (first_room == NULL)
      last_room = first_room = target;
   else
      last_room = last_room->next = target;
}

/**@brief
 * Variavel externa global responsavel por informar se os quartos estão carregados ou não\n
 * Se verdadeiro, os quartos ja estão inicializadas, caso contrario não existem quartos, ou falha ao ler o arquivo
*/
int rooms_loaded = 0;

/**@brief
 * Procedimento responsavel por carregar toda a arvore binaria de quartos de acordo com as estruturas salvas em um arquivo de texto (binario)
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int load_all_rooms(){
   if (rooms_loaded) return 0;

   FILE *fp = fopen("rooms/total", "r");
   if (fp == NULL) return 0;

   int total = 0;
   fscanf(fp, "%i", &total);
   fclose(fp);

   for (int i = 0; i < total; i++)
      load_room(i);

   if (total)
      last_room->next = NULL;

   rooms_loaded = 1;

   return 1;
}

/**@brief
 * Função responsavel por liberar a memoria alocada de todas as struct Room carregadas no sistema
*/
void release_rooms(){
   Room *curr = first_room;

   while (curr != NULL){
      Room *temp = curr;
      curr = curr->next;
      free(temp);
   }

   rooms_loaded = 0;
}

/**@brief
 * Procedimento responsavel por exibir todos os itens do sub-menu de Quarto.\n\n
 * 0 - Volta ao menu principal\n\n
 * P - Disponiveis - show_availables()\n
 * A - Adicionar quarto - add_room()\n
 * M - Mostrar quarto - show_room()\n
 * E - Editar quarto - edit_room()\n
 * R - Remover quarto - del_room()\n
 * L - Listar todos - show_all_rooms()
*/
void room_menu(){
   char option;

   load_all_rooms();

   do {
      printf("Voltar: 0\n\n");
      printf("Disponiveis: P\n\n");

      printf("A: Adicionar quarto\n");
      printf("M: Mostrar quarto\n");
      printf("E: Editar quarto\n");
      printf("R: Remover quarto\n");
      printf("L: Listar todos\n\n");

      printf("\nSua opcao: ");

      char buffer[10];
      afgets(buffer, 10);
      sscanf(buffer, "%c", &option);

      if (option == 48)
         continue;

      int res;

      switch (option){
         case 'P':
            res = show_availables();
            break;

         case 'A':
            res = add_room();
            break;

         case 'M':
            res = show_room();
            break;

         case 'E':
            res = edit_room();
            break;

         case 'R':
            res = del_room();
            break;

         case 'L':
            res = show_all_rooms();
            break;

         default:
            res = 1;
            printf("Opcao invalida\n");
      }

      if (!res)
         printf("\nErro ao executar a opcao !\n");

      pause();
      clrscr();
   } while (option != 48);

   save_all_rooms();
}