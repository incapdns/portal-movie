/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#ifndef CLIENTS_H  
/*!
  \def CLIENTS_H
  Declara que "CLIENTS_H" está definido na aplicação, significando a já existência do mesmo
*/
#define CLIENTS_H
#include "includes.h"

/**
 * \typedef typedef struct Client Client
 * @brief Seta o alias "Client" para a estrutura do tipo de dado "struct Client"
 */
/**
 * \struct Client
 * @brief Esta é a estrutura do cliente, que por sua vez é uma arvore binaria, e ela é responsavel por armazenar as informações do cliente, tal como o id, nome, endereço, telefone, pontos, etc
 */
typedef struct Client {
   /**
    * @name Campos da estrutura
   */
   /*@{*/
   int id;   /**< O ID do cliente */
   char name[55]; /**< O nome do cliente */
   char address[100]; /**< O endereço residencial do cliente */
   char phone[25]; /**< O telefone de contato do cliente */
   float points; /**< Quantidade de pontos de fidelidade */
   /*@}*/

   /**
    * @name Campos internos temporários
   */
   /*@{*/
   float total;
   float warn_points;
   int win_points;
   /*@}*/

   /**
    * @name Continuação (arvore binaria)
   */
   /*@{*/
   struct Client *next;  /**< Ponteiro para o proxima elemento da estrutura Client */
   /*@}*/
} Client;
/** @var Client::total
 *  Ele é usado para armazenar o total da fatura a ser gerado pelo procedimento bill_client()\n
 *  É usado apenas para exibição da fatura em bill_client(), possui um valor temporario e não representa o valor atual, pois o campo é atualizado a cada chmada da função para calculos internos
 */
/** @var Client::warn_points
 *  Ele é usado para armazenar o total de pontos de fidelidade que será gasto para desconto apos o fechamento / conclusão da fatura
 *  É usado apenas para exibição da fatura em bill_client(), possui um valor temporario e não representa o valor atual, pois o campo é atualizado a cada chmada da função para calculos internos
 */
/** @var Client::win_points
 *  Ele é usado para armazenar o total de pontos de fidelidade que será ganho apos o fechamento / conclusão da fatura
 *  É usado apenas para exibição da fatura em bill_client(), possui um valor temporario e não representa o valor atual, pois o campo é atualizado a cada chmada da função para calculos internos
 */

extern Client *first_client;

//Obter ID de cliente valido (se filtro ativado)
int ask_client_id(int, int);

//Editar cliente
Client *editClient(Client*, int);

//Mostras informações do cliente
Client *showClient(Client*);

//Retornar cliente por ID
Client *getClient(int);

//Proc de pesquisar clientes
int search_clients();

//Proc de adicionar clientes
int add_client();

//Proc de mostrar cliente
int show_client();

//Proc de editar cliente
int edit_client();

//Proc de deletar cliente
int del_client();

//Proc de exibir fatura
int bill_client();

/*
   INICIO: Gravar, salvar, carregar, liberar dados do arquivo !
*/
int show_all_clients();

int save_all_clients();

void load_client(int);

extern int clients_loaded;

int load_all_clients();

void release_clients();
/*
   FIM: Gravar, salvar, carregar, liberar dados do arquivo !
*/

//Mostrar menu
void client_menu();

#endif