#define _GNU_SOURCE

#include "settings.h"
#include "employees.h"
#include "rooms.h"

/**@brief
 * Variavel externa global do tipo time_t, que é a data atual do sistema
*/
time_t date;

/**@brief
 * Variavel externa global que contem a informação se o objeto time_t date está ou não inicializado
*/
int started = 0;

/**@brief
 * Está variavel externa global é a representação em string do objeto time_t date, que é a data atual do sistema
*/
char *b_system_date;

/**@brief
 * Procedimento responsavel por formatar ou resetar todo o sistema, ele irá deletar todos os clientes/funcionarios/quartos/estadias alem de remover a data atual e valor do desconto
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int reset_all(){
   release_clients();
   save("clients/total", "0");

   release_employees();
   save("employees/total", "0");

   release_rooms();
   save("rooms/total", "0");

   release_stays();
   save("stays/total", "0");

   remove("settings/discount");

   remove("settings/date");

   return 1;
}

/**@brief
 * Esta função retorna um struct Result contendo os clientes (getClient(client_id)) que estão dentro da Result passada por parametro\n
 * 
 * A Result passada por parametro contem o numero de estadias (.found), e os itens (.itens) que são as proprias estadias (Stay**)
 * 
 * @param [out] query: Estrutura Result contendo as estadias
 * 
 * @retval Result: Uma estrutura Result com a conversão de tipo .itens void** para Client**
*/
Result getClientsByResult(Result *query){
   Stay **stays = (Stay**) query->itens;

   int usize = sizeof(Client*);
   int size = usize;

   Client **clients = malloc(size);
   Result qclients = {.found = 0, .itens = (void**) clients};

   for(int i = 0; i < query->found; i++){
      Stay *stay = stays[i];
      Client *client = getClient(stay->client_id);
      if(!inResult(&qclients, client))
      {
         client->total = client->win_points = client->points = 0;
         if(qclients.found == 0)
            clients[0] = client;
         else {
            size += usize;
            clients = realloc(clients, size);
            clients[qclients.found] = client;
         }

         qclients.found++;
      }
   }

   return qclients;
}

/**@brief
 * Função responsavel por listar todas as estadias vencidas cuja data de saida seja menor ou igual ao parametro time_t end com execção do Stay *exception\n\n
 * Este procedimento obtem todos as estadias vencidas obtidas da chamada getStaysExpired(), e exibe na tela usando atravez função warnStaysExpired() que é responsavel por printa-las.\n\n
 * Apos isso, ele pergunta se deseja concluir todas as estadias listadas ou não ( 1 = prosseguir, 0 = desistir ), se a resposta for 1, todas as estadias com exceção do Stay *exception são concluidas e deletadas\n
 * Caso contrario, se a resposta for 0, a função retorna o codigo 2
 * 
 * @param [in] end: Objeto referente a data final
 * @param [out] exception: Estrutura Stay* a ser ignorada nas estadias expiradas
 *  
 * @retval 1: Procedimento completado com sucesso
 * @retval 2: Usuário cancelou a operação
*/
int check_expired_stays(time_t end, Stay *exception){
   char buffer[100];
   strftime(buffer, 17, "%d/%m/%Y %H:%M", localtime(&end));

   Result qstays = getStaysExpired(end, exception);

   Stay **stays = (Stay**) qstays.itens;

   if(qstays.found){
      printf("Data Saida: %s\n", buffer);
      warnStaysExpired(qstays);
   } else
      printf("[1]: Prosseguir, [0]: Desistir\n");

   int option = askValidNumber("Sua opcao: ", NULL, NULL);

   if(option == 0){
      printf("\nUsuario cancelou a operacao\n");
      return 2;
   }

   Result qclients = getClientsByResult(&qstays);

   Client **clients = (Client**) qclients.itens;

   Client *client;
   if(exception != NULL)
      client = getClient(exception->client_id);

   if(exception != NULL && !inResult(&qclients, client)){
      int key = qclients.found++;
      int size = qclients.found * sizeof(Client*);
      
      if(key > 0)
         clients = realloc(qclients.itens, size);

      clients[key] = getClient(exception->client_id);
   }
   
   if(qclients.found){
      char *msg = qclients.found > 1 ? "\n---- FATURAS ----\n" : "\nFatura:\n";
      
      printf("%s", msg);

      for(int i = 0; i < qclients.found; i++){
         Client *client = clients[i];

         printBill(client);

         client->total = 0;

         client->points -= client->warn_points;

         client->points += client->win_points;

         printf("\n----------------\n\n");

         if(i + 1 < qclients.found){
            pause();
         }
      }
   }

   for(int i = 0; i < qstays.found; i++)
      delStay(stays[i]);

   free(clients);

   if(qstays.found) 
      free(stays);

   date = end;
   mwrite("settings/date", &end, sizeof(time_t), 1);

   strftime(b_system_date, 17, "%d/%m/%Y %H:%M", localtime(&date));

   return 1;
}

/**@brief
 * Procedimento responsavel por setar uma data futura ao sistema, a aplicação ira persistir em uma data maior que a atual.\n
 * Este procedimento ira analisar o retorno da chamada check_expired_stays() com a nova data, caso o retorno seja 1 a operação é completada com sucesso, caso contrario a data permanece a mesma.
 * 
 * @retval 1: Procedimento completado com sucesso
 * @retval 2: Usuário cancelou a operação
*/
int set_future_date(){
   char buffer[100];
   int err = 0;

   if (started){
      strftime(buffer, 100, "%d/%m/%Y %H:%M", localtime(&date));
      printf("Data atual: %s\n\n", buffer);
      printf("Setar uma data futura\n");
   } else
      printf("Data inicial do sistema\n");

   time_t now;

   do {
      if (err)
         printf("\nA data precisa ser maior que a atual\n");

      now = ask_date(started, 0);
      err = started && difftime(now, date) <= 0;
   } while (err);

   int option = check_expired_stays(date, NULL);
   if(option == 2) return 2;

   date = now;
   mwrite("settings/date", &now, sizeof(time_t), 1);

   strftime(b_system_date, 17, "%d/%m/%Y %H:%M", localtime(&date));

   return 1;
}

/**@brief
 * É a variavel externa global contendo o valor do preço (R$) referente a cada pontuação unitaria (1 Pt)
*/
float discount;

/**@brief
 * Procedimento responsavel por atribuir o preço (R$) a cada pontuação unitaria (1 Pt) e salvar em um arquivo de texto binario
 * 
 * @retval 1: Procedimento completado com sucesso
*/
int discount_config(){
   float price;
   printf("Qual valor (R$) atribuir a 1Pts?\n");
   printf("Sua opcao (R$1->1Pt): ");
   scanf("%f", &price);
   setbuf(stdin, NULL);

   discount = price;

   mwrite("settings/discount", &price, sizeof(float), 1);

   setbuf(stdin, NULL);

   return 1;
}

/**@brief
 * Procedimento responsavel por carregar as informações referente ao preço (R$) de cada pontução unitaria (1 Pt) e a data atual do sistema
*/
void load_config(){
   load_all_stays();

   load_all_clients();

   FILE *file = fopen("settings/date", "r");

   started = 0;

   if (file != NULL){
      fread(&date, sizeof(time_t), 1, file);

      started = 1;
   } else {
      set_future_date();
      pause();
      clrscr();
   }

   fclose(file);

   b_system_date = malloc(17);

   strftime(b_system_date, 17, "%d/%m/%Y %H:%M", localtime(&date));

   file = fopen("settings/discount", "r");
   if(file != NULL){
      fread(&discount, sizeof(float), 1, file);
   } else {
      discount_config();
      pause();
      clrscr();
   }

   fclose(file);
}

/**@brief
 * Procedimento responsavel por exibir todos os itens do sub-menu de Configuracao.\n\n
 * 0 - Volta ao menu principal\n\n
 * S - Setar data futura do sistema - set_future_date()\n
 * R - Resetar / formatar todo sistema - reset_all()\n
*/
void setting_menu(){
   char option;

   do {
      printf("Voltar: 0\n\n");

      printf("S: Setar data futura do sistema\n");
      printf("D: Desconto por pts de fidelidade\n");
      printf("R: Resetar / formatar todo sistema\n\n");

      printf("\nSua opcao: ");

      char buffer[10];
      afgets(buffer, 10);
      sscanf(buffer, "%c", &option);

      if (option == 48) continue;

      int res;

      switch (option){
         case 'S':
            res = set_future_date();
            break;

         case 'D':
            res = discount_config();
            break;

         case 'R':
            res = reset_all();
            break;

         default:
            res = 1;
            printf("Opcao invalida\n");
      }

      if (!res)
         printf("Erro ao executar a opcao !\n");

      pause();
      clrscr();
   } while (option != 48);
}