/*!
  \def _GNU_SOURCE
  Obter acesso as várias funções de extensão GNU / Linux não padronizadas e omitidas no padrão POSIX
*/
#define _GNU_SOURCE

#ifndef STAYS_H  
/*!
  \def STAYS_H
  Declara que "STAYS_H" está definido na aplicação, significando a já existência do mesmo
*/
#define STAYS_H
#include "includes.h"
#include "clients.h"
#include "rooms.h"

/**
 * \typedef typedef struct Stay Stay
 * @brief Seta o alias "Stay" para a estrutura do tipo de dado "struct Stay"
 */
/**
 * \struct Stay
 * @brief Esta é a estrutura da estadia, que por sua vez é uma arvore binaria, e ela é responsavel por armazenar as informações da estadia, tal como a data de entrada e saida, quarto, cliente, numero de hospedes, valor do quarto para calculo, etc.
 */
typedef struct Stay {
   /**
    * @name Campos da estrutura
   */
   /*@{*/
   int id;  /**< O ID da estadia */
   int guests; /**< O número de hospedes */
   time_t start; /**< Objeto time_t referente a data de entrada */
   time_t end;  /**< Objeto time_t referente a data de saida */
   int client_id;  /**< O ID do cliente responsavel por criar a estadia */
   int room_id;  /**< O ID do quarto em questão */
   float s_room_price; 
   /*@}*/

   /**
    * @name Continuação (arvore binaria)
   */
   /*@{*/
   struct Stay *next;  /**< Ponteiro para o proxima elemento da estrutura Stay */
   /*@}*/
} Stay;
/** @var Stay::s_room_price
 *  O preço do quarto no momento de cadastro, ao modificar o numero de hospedes ou a data de entrada / saida esse parametro é atualizado com o preço do quarto atual
 */

//Obter ID de estadia valida (se filtro ativado)
int ask_stay_id(int, int);

//Retorna as estadias expiradas
Result getStaysExpired(time_t end, Stay *);

//Exibe a mensagem das estadias expiradas
void warnStaysExpired(Result);

//Retornar as estadias por cliente
Result getStaysByClient(Client *item);

//Pergunte e converte em data time_t
time_t ask_date(int, int);

//Editar estadia
Stay *editStay(Stay*, int);

//Mostras informações de estadia
Stay *showStay(Stay*);

//Retornar estadia por ID
Stay *getStay(int);

//Deletar estadia
int delStay(Stay*);

//Printar fatura do cliente
void printBill(Client *item);

//Proc de pesquisar estadias
int search_stays();

//Proc de adicionar estadia
int add_stay();

//Proc de mostrar estadia
int show_stay();

//Proc de editar estadia
int edit_stay();

//Proc de fechar / dar baixa na estadia
int close_stay();

//Proc de deletar estadia
int del_stay();

/*
   INICIO: Gravar, salvar, carregar, liberar dados do arquivo !
*/
int show_all_stays();

int save_all_stays();

void load_stay(int);

extern int stays_loaded;

int load_all_stays();

void release_stays();
/*
   FIM: Gravar, salvar, carregar, liberar dados do arquivo !
*/

//Mostrar menu
void stay_menu();

#endif
