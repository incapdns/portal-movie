#include "helpers.h"

/** @brief
 *  Variavel externa global responsavel por conter a data inicial do objeto time_t (normalmente 1900)
 */
int diff_year;

/**@brief
 * Esta função retorna informando se o elemento passado como parametro item está ou não presente na estrutura Result\n
 * 
 * A função recebe como parametro um ponteiro para a estrutura Result, estrutura da qual armazena um vetor de ponteiros de dinâmicos tipos
 * 
 * @param [out] result: Ponteiro do estrutura de Result
 * @param [out] exception: Elemento (que é do tipo ponteiro) a ser pesquisado
 * 
 * @retval 0: Item não está presente no vetor
 * @retval 1: Item encontrado
*/
int inResult(Result *result, void *item){
   for(int i = 0; i < result->found; i++)
      if(result->itens[i] == item)
         return 1;

   return 0;
}

/**@brief
 * Está função salva qualquer tipo de dado a um arquivo de texto como sendo binario
 * 
 * 
 * @param [in] name: Nome do arquivo
 * @param [in] ptr: Ponteiro do elemento
 * @param [in] size: Tamanho em bytes
 * @param [in] count: Quantidade
*/
void mwrite(const char *name, const void *ptr, int size, int count){
   FILE *file = fopen(name, "wb");
   fwrite(ptr, size, count, file);
   fclose(file);
}

/**@brief
 * Está função salva qualquer tipo de dado a um arquivo de texto simples
 * 
 * 
 * @param [in] filename: Nome do arquivo
 * @param [in] buffer: String a ser salva
*/
void save(char *filename, char *buffer){
  FILE *fp;
  fp = fopen(filename, "wb");
  fputs(buffer, fp);
  fclose(fp);
}

/**@brief
 * Esta função verifica se o ultimo caractere da string é a quebra de linha, se positivo, ele remove -1 caractere da string (NULL Terminator)
 * 
 * 
 * @param [out] buffer: String a ser corrigida
*/
void fix(char *buffer){
  int len = strlen(buffer);
  if(buffer[len - 1] == '\n')
    buffer[len - 1] = 0;
}

/**@brief
 * Os parametros char *d e char *m devem possuir exatos 2 caracteres, e o parametros char *y 4 caracateres\n 
 * atoi(d) e atoi(m) devem ser respectivamente menores que 32 e 13 e maiores que zero, caso contrario é retornado 0\n
 * O valor de retorno é a verificação dos parametros, 1 se atendeu os critérios, caso contrario 0
 * 
 * @param [out] d: String do dia (DD)
 * @param [out] m: String do mês (MM)
 * @param [out] y: String do ano (YYYY)
 * 
 * @retval 0: Campos invalidos
 * @retval 1: Campos validos
*/
int checkDate(char *d, char *m, char *y){
   int vdm = strlen(d) == 2 && strlen(m) == 2;
   int vy = strlen(y) == 4;
   if (!vdm || !vy) return 0;

   int day = atoi(d) > 0 && atoi(d) <= 31;
   int month = atoi(m) > 0 && atoi(m) <= 12; //Recai: month-1;

   return day && month;
}

/**@brief
 * Os parametros char *h e char *m devem possuir exatos 2 caracteres, e a atoi(h) e atoi(m) ser respectivamente menores que 24 e 60 e maiores que zero\n
 * O valor de retorno é a verificação dos parametros, 1 se atendeu os critérios, caso contrario 0
 * 
 * @param [out] h: String da hora (HH)
 * @param [out] m: String do mês (MM)
 * 
 * @retval 0: Campos invalidos
 * @retval 1: Campos validos
*/
int checkHour(char *h, char *m){
   int vhm = strlen(h) == 2 && strlen(m) == 2;
   if (!vhm) return 0;

   int hour = atoi(h) < 24 && atoi(h) >= 0;
   int min = atoi(m) < 60 && atoi(h) >= 0;
   return hour && min;
}

/**@brief
 * A função persiste na entrada (STDIN) de um inteiro valido [0-9], e tambem distingue entres outros caracatere invalidos [A-z] atravez da função sscanf e atoi, a mensagem a ser enviada (printf) para captura de entrada
 * está presente no 1º parametro da função: msg\n
 * A string de exceção está contida no 2º parametro: redirect, se a entrada for igual a string de execção (strcmp), 
 * antes de reentrar no loop solicitando outro numero, é redirecionado ao callback presente no terçeiro parametro: cb
 * 
 * @param [out] msg: Mensagem para perguntar
 * @param [out] redirect: Key de captura
 * @param [out] cb: Callback ao inserir o key de captura
 * 
 * @retval number: Número de entrada
*/
int askValidNumber(char *msg, char *redirect, int (*cb)(void)){
  int err = 0, in_cb;
  char buffer[100];
  int number;

  do {
    if (err && !in_cb)
      printf("\nErro: Insira um numero valido !\n");

    err = in_cb = 0;

    printf("%s", msg);
    afgets(buffer, 100);
    sscanf(buffer, "%i", &number);
    sscanf(buffer, "%s", buffer);

    if(redirect && strcmp(buffer, redirect) == 0)
      in_cb = 1, cb();
    else
      err = atoi(buffer) != number;
  } while (err || in_cb);

  return number;
}

/** @brief
 *  Função responsavel por definir a variavel externa global diff_year contendo a data inicial do objeto time_t, que normalmente é 1900
 */
void set_diff_year(){
  time_t t = time(NULL);
  struct tm *tm = localtime(&t);
  tm->tm_year = 2021;
  char year[5];
  strftime(year, 5, "%Y", tm);

  diff_year = atoi(year) - 2021;
}

/**@brief
 * A função verifica se o dia, mês e ano do primeiro parametro oa é igual ao do segundo parametro ob, ignorando hora e segundo
 * 
 * @param [in] oa: struct tm da 1ª data
 * @param [in] ob: struct tm da 2ª data
 * 
 * @retval 0: O dia, mês e ano são diferentes
 * @retval 1: O dia, mês e ano são iguais
*/
int sameDay(struct tm oa, struct tm ob){
  time_t ta = mktime(&oa);
  time_t tb = mktime(&ob);

  struct tm a = *localtime(&ta);
  struct tm b = *localtime(&tb);

  int vd = a.tm_mday == b.tm_mday;
  int vm = a.tm_mon == b.tm_mon;
  int vy = a.tm_year == b.tm_year;

  return vd && vm && vy;
}

/**@brief
 * A função contabiliza a diferença de dias (dd/mm/yyyy) entre os parametros respectivamente fornecidos (atravêz da chamada sameDay()), e contabiliza +1 dia caso a data final (1º parametro) possuir o horario (HH:mm) superior as 12:00 horas, ex: 12:01
 * 
 * @param [in] end: Objeto time_t da data final
 * @param [in] start: Objeto time_t da data inicial
 * 
 * @retval number: Diferença em dias
*/
int diffdays(time_t end, time_t start){
  struct tm te = *localtime(&end);
  struct tm ta = *localtime(&start);

  if(difftime(end, start) <= 0) return -1;

  if(sameDay(te, ta)) return 0;

  int days = 0;

  do {
    days++;

    ta.tm_mday += 1;
  } while(!sameDay(te, ta));

  int case1 = te.tm_hour == 12 && te.tm_min > 0;
  int case2 = te.tm_hour > 12;

  if(case1 || case2)
    days++;

  return days;
}